# 🌍 FreelanceAfrica

**Marketplace for African Freelancers and Clients**

> IFM Project #38/BIT (2A) — Electronic Commerce (ITU_07424)
> Date: 15/May/2026

A continent-focused freelance marketplace connecting African freelancers
(writers, designers, developers) with local and regional clients —
featuring **M-Pesa Daraja** and **Flutterwave** sandbox payment integration,
an **escrow system**, **real-time messaging**, and **role-based dashboards**.

---

## 📁 Project Structure

```
freelance-africa/
├── backend/                 # Node.js + Express + Socket.IO API
│   ├── config/db.js          # MySQL connection pool
│   ├── controllers/          # Business logic (auth, gigs, orders, payments...)
│   ├── middleware/            # JWT auth & role guards
│   ├── routes/               # API route definitions
│   ├── utils/                # Email utility (Nodemailer)
│   ├── uploads/              # Uploaded files (gig images, deliveries)
│   ├── .env.example
│   ├── package.json
│   └── server.js              # Entry point
│
├── frontend/                 # React.js (Tailwind CSS) application
│   ├── public/index.html
│   ├── src/
│   │   ├── components/        # Navbar, Footer, GigCard, etc.
│   │   ├── context/AuthContext.js
│   │   ├── pages/              # All route pages
│   │   ├── utils/api.js        # Axios instance + token refresh
│   │   ├── App.js
│   │   └── index.js
│   ├── tailwind.config.js
│   ├── postcss.config.js
│   ├── .env.example
│   └── package.json
│
└── database/
    ├── schema.sql             # Full 3NF normalized schema (19 tables)
    └── seed.sql               # Demo data (3 freelancers, 2 clients, 3 gigs)
```

---

## 🚀 Quick Start

### 1. Database Setup

```bash
mysql -u root -p < database/schema.sql
mysql -u root -p < database/seed.sql
```

This creates the `freelanceafrica` database with 19 normalized tables
(users, gigs, gig_packages, orders, payments, wallets, reviews, messages,
disputes, notifications, refresh_tokens, audit_log, etc.) and seeds it with
demo freelancers, clients, and gigs.

**Demo login (after seeding):** all seeded users have password `Password123`
- Admin: `admin@freelanceafrica.com`
- Freelancer: `baraka.dev@example.com` (Web Dev), `amina.design@example.com` (Design), `chidi.write@example.com` (Writing)
- Client: `john.client@example.com`, `sarah.client@example.com`

### 2. Backend Setup

```bash
cd backend
cp .env.example .env      # then edit DB credentials, JWT secrets, etc.
npm install
npm run dev                # starts on http://localhost:5000
```

Required `.env` values to configure:
- `DB_*` — your MySQL credentials
- `JWT_SECRET` / `JWT_REFRESH_SECRET` — any long random strings
- `MPESA_*` — get sandbox keys from https://developer.safaricom.co.ke
- `FLW_*` — get sandbox keys from https://dashboard.flutterwave.com
- `SMTP_*` — Gmail App Password (for email verification)

### 3. Frontend Setup

```bash
cd frontend
cp .env.example .env
npm install
npm start                  # starts on http://localhost:3000
```

---

## 🧩 Features Implemented (per Proposal Objectives)

| Objective | Status |
|---|---|
| 3NF Database Schema (19 tables) | ✅ `database/schema.sql` |
| React.js responsive frontend (homepage, catalog, gig detail, dashboard) | ✅ |
| Node.js/Express backend, JWT auth, RBAC (freelancer/client/admin) | ✅ |
| Gig & order management APIs | ✅ |
| Real-time messaging (Socket.IO) | ✅ |
| M-Pesa Daraja (sandbox) integration | ✅ |
| Flutterwave (sandbox) integration | ✅ |
| Escrow payment flow | ✅ |
| Order lifecycle (pending → active → delivered → completed/disputed) | ✅ |
| Ratings & reviews system | ✅ |
| Admin dashboard (stats, user management, dispute resolution) | ✅ |
| Email verification | ✅ |

---

## 🔑 Key API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/auth/register` | Register (client/freelancer) |
| POST | `/api/auth/login` | Login → JWT access + refresh tokens |
| GET  | `/api/gigs` | Browse/search/filter gig catalog |
| GET  | `/api/gigs/:slug` | Gig detail with packages, reviews |
| POST | `/api/gigs` | Create gig (freelancer, max 20) |
| POST | `/api/orders` | Place order |
| PUT  | `/api/orders/:id/deliver` | Freelancer delivers work |
| PUT  | `/api/orders/:id/complete` | Client accepts → releases escrow |
| POST | `/api/payments/mpesa/stk-push` | Trigger M-Pesa STK push |
| POST | `/api/payments/flutterwave/initiate` | Get Flutterwave checkout link |
| GET/POST | `/api/messages/:order_id` | Order chat (+ Socket.IO real-time) |
| POST | `/api/reviews` | Submit review after order completion |
| GET  | `/api/admin/stats` | Admin dashboard stats |
| GET/PUT | `/api/admin/disputes` | View & resolve disputes |

---

## 🛠 Tech Stack

- **Frontend:** React.js, React Router, Tailwind CSS, Socket.IO Client, Axios
- **Backend:** Node.js, Express.js, Socket.IO, JWT, bcrypt
- **Database:** MySQL (3NF normalized, 19 tables)
- **Payments:** M-Pesa Daraja API (sandbox), Flutterwave API (sandbox)
- **Email:** Nodemailer (SMTP)

---

## 📝 Next Steps for Coursework

1. Run the SQL scripts and start both servers locally
2. Test the full order flow: register → browse gigs → place order →
   pay (sandbox) → freelancer delivers → client completes → leave review
3. Take screenshots for **Chapter 4 (Implementation)** of your report
4. Run OWASP Top-10 checks and UAT with 5 participants for **Chapter 5**
5. Document the ERD (derive from `schema.sql`) for **Chapter 3**
