// src/components/common/Navbar.js
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import toast from 'react-hot-toast';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
    toast.success('Logged out');
    navigate('/');
  };

  return (
    <nav className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between h-16">
        {/* Logo */}
        <Link to="/" className="text-2xl font-extrabold text-green-700 flex items-center gap-2">
          🌍 <span>FreelanceAfrica</span>
        </Link>

        {/* Center nav links */}
        <div className="hidden md:flex items-center gap-6 text-sm font-medium text-gray-600">
          <Link to="/gigs" className="hover:text-green-700 transition">Browse Services</Link>
          {user?.role === 'client' && (
            <Link to="/orders" className="hover:text-green-700 transition">My Orders</Link>
          )}
          {user?.role === 'freelancer' && (
            <Link to="/dashboard" className="hover:text-green-700 transition">Dashboard</Link>
          )}
          {user?.role === 'admin' && (
            <Link to="/admin" className="hover:text-green-700 transition">Admin</Link>
          )}
        </div>

        {/* Right side */}
        <div className="flex items-center gap-3">
          {user ? (
            <div className="relative">
              <button
                onClick={() => setMenuOpen(!menuOpen)}
                className="flex items-center gap-2 px-3 py-2 rounded-full hover:bg-gray-100 transition"
              >
                {user.avatar_url
                  ? <img src={user.avatar_url} alt="" className="w-8 h-8 rounded-full" />
                  : <div className="w-8 h-8 rounded-full bg-green-600 text-white flex items-center justify-center font-bold text-sm">
                      {user.first_name?.[0]}
                    </div>
                }
                <span className="text-sm font-medium text-gray-700 hidden md:block">{user.first_name}</span>
                <span className="text-xs text-gray-400">▾</span>
              </button>
              {menuOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white border border-gray-100 rounded-xl shadow-lg py-2 z-50">
                  <Link to="/dashboard" onClick={() => setMenuOpen(false)}
                    className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">Dashboard</Link>
                  <Link to="/orders" onClick={() => setMenuOpen(false)}
                    className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">My Orders</Link>
                  {user.role === 'admin' && (
                    <Link to="/admin" onClick={() => setMenuOpen(false)}
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">Admin Panel</Link>
                  )}
                  <hr className="my-1 border-gray-100" />
                  <button onClick={handleLogout}
                    className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50">
                    Sign out
                  </button>
                </div>
              )}
            </div>
          ) : (
            <>
              <Link to="/login"
                className="text-sm font-medium text-gray-600 hover:text-green-700 transition px-3 py-2">
                Sign in
              </Link>
              <Link to="/register"
                className="bg-green-600 hover:bg-green-700 text-white text-sm font-semibold px-5 py-2 rounded-full transition">
                Join Free
              </Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}
