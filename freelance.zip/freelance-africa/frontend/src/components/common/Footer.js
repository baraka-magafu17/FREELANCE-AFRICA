// src/components/common/Footer.js
import React from 'react';
import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-400 py-12 px-6 mt-auto">
      <div className="max-w-6xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
        <div>
          <div className="text-white font-bold text-lg mb-3">🌍 FreelanceAfrica</div>
          <p className="text-sm">Africa's premier freelance marketplace connecting talent with opportunity.</p>
        </div>
        <div>
          <div className="text-white font-semibold mb-3">For Clients</div>
          <ul className="space-y-2 text-sm">
            <li><Link to="/gigs" className="hover:text-white transition">Browse Services</Link></li>
            <li><Link to="/register?role=client" className="hover:text-white transition">Post a Project</Link></li>
          </ul>
        </div>
        <div>
          <div className="text-white font-semibold mb-3">For Freelancers</div>
          <ul className="space-y-2 text-sm">
            <li><Link to="/register?role=freelancer" className="hover:text-white transition">Start Selling</Link></li>
            <li><Link to="/dashboard" className="hover:text-white transition">Dashboard</Link></li>
          </ul>
        </div>
        <div>
          <div className="text-white font-semibold mb-3">Payments</div>
          <ul className="space-y-2 text-sm">
            <li>M-Pesa (Tanzania · Kenya)</li>
            <li>Flutterwave (Nigeria)</li>
            <li>Escrow Protected</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-gray-800 pt-6 text-center text-sm">
        <p>© {new Date().getFullYear()} FreelanceAfrica — IFM Project #38/BIT(2A) · ITU_07424</p>
      </div>
    </footer>
  );
}
