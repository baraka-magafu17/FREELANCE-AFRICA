// src/components/gigs/GigCard.js
import React from 'react';
import { Link } from 'react-router-dom';

export default function GigCard({ gig }) {
  const stars = '⭐'.repeat(Math.round(gig.avg_rating || 0));
  return (
    <Link to={`/gigs/${gig.slug}`} className="block rounded-xl border border-gray-100 hover:shadow-md transition overflow-hidden group bg-white">
      <div className="h-44 bg-gray-100 overflow-hidden">
        {gig.thumbnail_url ? (
          <img src={gig.thumbnail_url} alt={gig.title}
            className="w-full h-full object-cover group-hover:scale-105 transition" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-5xl bg-green-50">💼</div>
        )}
      </div>
      <div className="p-4">
        <div className="flex items-center gap-2 mb-2">
          {gig.avatar_url
            ? <img src={gig.avatar_url} alt={gig.username} className="w-6 h-6 rounded-full" />
            : <div className="w-6 h-6 rounded-full bg-green-200 flex items-center justify-center text-xs font-bold text-green-700">
                {gig.first_name?.[0]}
              </div>
          }
          <span className="text-xs text-gray-500">{gig.username}</span>
        </div>
        <h3 className="text-sm font-semibold text-gray-800 line-clamp-2 mb-3 group-hover:text-green-700 transition">
          {gig.title}
        </h3>
        <div className="flex items-center justify-between">
          <div className="text-xs text-yellow-500">
            {gig.avg_rating > 0 ? `${stars} ${Number(gig.avg_rating).toFixed(1)} (${gig.total_reviews})` : 'New'}
          </div>
          <div className="text-sm font-bold text-gray-900">
            From {gig.currency || 'USD'} {Number(gig.starting_price || 0).toLocaleString()}
          </div>
        </div>
      </div>
    </Link>
  );
}
