// src/pages/OrderDetailPage.js
import React, { useEffect, useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { io } from 'socket.io-client';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import Navbar from '../components/common/Navbar';
import toast from 'react-hot-toast';

const STATUS_COLORS = {
  pending:            'bg-yellow-100 text-yellow-700',
  active:             'bg-blue-100 text-blue-700',
  delivered:          'bg-purple-100 text-purple-700',
  revision_requested: 'bg-orange-100 text-orange-700',
  completed:          'bg-green-100 text-green-700',
  disputed:           'bg-red-100 text-red-700',
  cancelled:          'bg-gray-100 text-gray-600',
};

export default function OrderDetailPage() {
  const { id }  = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [order,    setOrder]    = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMsg,   setNewMsg]   = useState('');
  const [loading,  setLoading]  = useState(true);
  const [payGateway, setPayGateway] = useState('mpesa');
  const [phone,    setPhone]    = useState('');
  const chatEndRef = useRef(null);
  const socketRef  = useRef(null);

  useEffect(() => {
    fetchOrder();
    fetchMessages();

    // Connect socket
    socketRef.current = io(process.env.REACT_APP_SOCKET_URL || 'http://localhost:5000');
    socketRef.current.emit('join_order', id);
    socketRef.current.on('new_message', (msg) => {
      setMessages(prev => [...prev, msg]);
    });
    return () => socketRef.current?.disconnect();
  // eslint-disable-next-line
  }, [id]);

  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const fetchOrder = async () => {
    try {
      const res = await api.get(`/orders/${id}`);
      setOrder(res.data.data);
    } catch { navigate('/orders'); }
    finally { setLoading(false); }
  };

  const fetchMessages = async () => {
    try {
      const res = await api.get(`/messages/${id}`);
      setMessages(res.data.data || []);
    } catch {}
  };

  const sendMessage = async (e) => {
    e.preventDefault();
    if (!newMsg.trim()) return;
    try {
      await api.post(`/messages/${id}`, { body: newMsg });
      setNewMsg('');
    } catch { toast.error('Failed to send message'); }
  };

  const handleMpesaPay = async () => {
    if (!phone) return toast.error('Enter your M-Pesa phone number');
    try {
      await api.post('/payments/mpesa/stk-push', { order_id: id, phone_number: phone });
      toast.success('M-Pesa STK push sent! Check your phone.');
    } catch (err) { toast.error(err.response?.data?.message || 'Payment failed'); }
  };

  const handleFlutterwavePay = async () => {
    try {
      const res = await api.post('/payments/flutterwave/initiate', { order_id: id });
      window.location.href = res.data.data.payment_link;
    } catch (err) { toast.error(err.response?.data?.message || 'Payment failed'); }
  };

  const handleDeliver = async () => {
    try {
      await api.put(`/orders/${id}/deliver`, { message: 'Work delivered as requested.' });
      toast.success('Order delivered!');
      fetchOrder();
    } catch (err) { toast.error(err.response?.data?.message || 'Failed'); }
  };

  const handleComplete = async () => {
    try {
      await api.put(`/orders/${id}/complete`);
      toast.success('Order completed! Payment released.');
      fetchOrder();
    } catch (err) { toast.error(err.response?.data?.message || 'Failed'); }
  };

  const handleRevision = async () => {
    try {
      await api.put(`/orders/${id}/revision`, { reason: 'Revision requested by client' });
      toast.success('Revision requested');
      fetchOrder();
    } catch (err) { toast.error(err.response?.data?.message || 'Failed'); }
  };

  if (loading) return <div className="flex items-center justify-center min-h-screen text-green-600">Loading...</div>;
  if (!order)  return null;

  const isClient     = user?.user_id === order.client_id;
  const isFreelancer = user?.user_id === order.freelancer_id;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Navbar />
      <div className="max-w-5xl mx-auto px-4 py-8 w-full flex-1">
        {/* Header */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6 mb-6 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <p className="text-xs text-gray-400 mb-1">Order Ref: {order.order_ref}</p>
              <h1 className="font-bold text-xl text-gray-900">{order.gig_title}</h1>
              <p className="text-sm text-gray-500 mt-1">
                {isClient ? `Freelancer: ${order.freelancer_username}` : `Client: ${order.client_username}`}
              </p>
            </div>
            <div className="flex items-center gap-4">
              <span className={`px-3 py-1 rounded-full text-sm font-semibold capitalize ${STATUS_COLORS[order.status]}`}>
                {order.status.replace('_', ' ')}
              </span>
              <div className="text-right">
                <div className="font-bold text-lg text-green-700">{order.currency} {Number(order.amount).toLocaleString()}</div>
                <div className="text-xs text-gray-400">Due: {new Date(order.due_date).toLocaleDateString()}</div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Chat */}
          <div className="lg:col-span-2 bg-white rounded-2xl border border-gray-100 shadow-sm flex flex-col h-96">
            <div className="p-4 border-b border-gray-100 font-semibold text-gray-700">Order Chat</div>
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {messages.length === 0 && (
                <p className="text-center text-gray-400 text-sm mt-8">No messages yet. Say hello!</p>
              )}
              {messages.map((msg) => {
                const isMine = msg.sender_id === user?.user_id;
                return (
                  <div key={msg.message_id} className={`flex ${isMine ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-xs px-4 py-2 rounded-2xl text-sm ${
                      isMine ? 'bg-green-600 text-white rounded-br-sm' : 'bg-gray-100 text-gray-800 rounded-bl-sm'
                    }`}>
                      {!isMine && <div className="text-xs font-semibold mb-1 opacity-70">{msg.username}</div>}
                      {msg.body}
                      <div className="text-xs opacity-60 mt-1 text-right">
                        {new Date(msg.sent_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>
                  </div>
                );
              })}
              <div ref={chatEndRef} />
            </div>
            <form onSubmit={sendMessage} className="p-3 border-t border-gray-100 flex gap-2">
              <input value={newMsg} onChange={e => setNewMsg(e.target.value)}
                placeholder="Type a message..."
                className="flex-1 border border-gray-200 rounded-full px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-400" />
              <button type="submit"
                className="bg-green-600 text-white px-4 py-2 rounded-full text-sm hover:bg-green-700 transition">
                Send
              </button>
            </form>
          </div>

          {/* Actions Panel */}
          <div className="space-y-4">
            {/* Payment (client, pending, unpaid) */}
            {isClient && order.status === 'pending' && !order.is_paid && (
              <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
                <h3 className="font-semibold text-gray-700 mb-3">Complete Payment</h3>
                <div className="flex gap-2 mb-3">
                  {['mpesa', 'flutterwave'].map(g => (
                    <button key={g} onClick={() => setPayGateway(g)}
                      className={`flex-1 py-2 text-xs font-semibold rounded-lg transition ${
                        payGateway === g ? 'bg-green-600 text-white' : 'bg-gray-100 text-gray-600'
                      }`}>
                      {g === 'mpesa' ? '📱 M-Pesa' : '💳 Flutterwave'}
                    </button>
                  ))}
                </div>
                {payGateway === 'mpesa' ? (
                  <>
                    <input value={phone} onChange={e => setPhone(e.target.value)}
                      placeholder="e.g. 255712345678"
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm mb-3 focus:outline-none focus:ring-2 focus:ring-green-400" />
                    <button onClick={handleMpesaPay}
                      className="w-full bg-green-600 text-white font-bold py-3 rounded-xl hover:bg-green-700 transition text-sm">
                      Pay {order.currency} {Number(order.amount).toLocaleString()} via M-Pesa
                    </button>
                  </>
                ) : (
                  <button onClick={handleFlutterwavePay}
                    className="w-full bg-orange-500 text-white font-bold py-3 rounded-xl hover:bg-orange-600 transition text-sm">
                    Pay via Flutterwave
                  </button>
                )}
              </div>
            )}

            {/* Freelancer actions */}
            {isFreelancer && order.status === 'active' && (
              <button onClick={handleDeliver}
                className="w-full bg-blue-600 text-white font-bold py-3 rounded-xl hover:bg-blue-700 transition text-sm">
                📦 Mark as Delivered
              </button>
            )}

            {/* Client actions on delivery */}
            {isClient && order.status === 'delivered' && (
              <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm space-y-3">
                <h3 className="font-semibold text-gray-700">Review Delivery</h3>
                <button onClick={handleComplete}
                  className="w-full bg-green-600 text-white font-bold py-3 rounded-xl hover:bg-green-700 transition text-sm">
                  ✅ Accept & Release Payment
                </button>
                <button onClick={handleRevision}
                  className="w-full bg-orange-50 border border-orange-200 text-orange-600 font-bold py-3 rounded-xl hover:bg-orange-100 transition text-sm">
                  🔄 Request Revision
                </button>
              </div>
            )}

            {/* Order info */}
            <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm text-sm space-y-2">
              <div className="flex justify-between"><span className="text-gray-500">Package</span><span className="font-medium capitalize">{order.tier}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">Delivery</span><span className="font-medium">{order.delivery_days} days</span></div>
              <div className="flex justify-between"><span className="text-gray-500">Placed</span><span className="font-medium">{new Date(order.created_at).toLocaleDateString()}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">Due</span><span className="font-medium">{new Date(order.due_date).toLocaleDateString()}</span></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
