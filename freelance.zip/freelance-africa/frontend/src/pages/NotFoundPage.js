// src/pages/NotFoundPage.js
import React from 'react';
import { Link } from 'react-router-dom';
export default function NotFoundPage() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center text-center px-4">
      <div>
        <div className="text-8xl mb-6">🌍</div>
        <h1 className="text-5xl font-extrabold text-green-700 mb-2">404</h1>
        <p className="text-gray-500 mb-6">Page not found</p>
        <Link to="/" className="bg-green-600 text-white font-bold px-8 py-3 rounded-full hover:bg-green-700 transition">
          Go Home
        </Link>
      </div>
    </div>
  );
}
