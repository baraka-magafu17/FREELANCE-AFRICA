// src/pages/VerifyEmailPage.js
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../utils/api';

export default function VerifyEmailPage() {
  const { token } = useParams();
  const [status, setStatus] = useState('verifying'); // verifying | success | error

  useEffect(() => {
    api.get(`/auth/verify/${token}`)
      .then(() => setStatus('success'))
      .catch(() => setStatus('error'));
  }, [token]);

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
      <div className="bg-white rounded-2xl shadow-lg p-10 text-center max-w-md w-full">
        {status === 'verifying' && <><div className="text-5xl mb-4">⏳</div><p>Verifying your email...</p></>}
        {status === 'success'   && (
          <>
            <div className="text-6xl mb-4">✅</div>
            <h2 className="text-2xl font-bold text-green-700 mb-2">Email Verified!</h2>
            <p className="text-gray-500 mb-6">Your account is now active.</p>
            <Link to="/login" className="bg-green-600 text-white font-bold px-8 py-3 rounded-xl hover:bg-green-700 transition">
              Sign In
            </Link>
          </>
        )}
        {status === 'error'     && (
          <>
            <div className="text-6xl mb-4">❌</div>
            <h2 className="text-2xl font-bold text-red-600 mb-2">Verification Failed</h2>
            <p className="text-gray-500 mb-6">The link is invalid or has expired.</p>
            <Link to="/register" className="text-green-600 font-semibold hover:underline">Register again</Link>
          </>
        )}
      </div>
    </div>
  );
}
