// src/pages/GigDetailPage.js
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import Navbar from '../components/common/Navbar';
import Footer from '../components/common/Footer';
import toast from 'react-hot-toast';

export default function GigDetailPage() {
  const { slug }   = useParams();
  const { user }   = useAuth();
  const navigate   = useNavigate();
  const [gig, setGig]           = useState(null);
  const [loading, setLoading]   = useState(true);
  const [selPkg, setSelPkg]     = useState(0);   // selected package index
  const [ordering, setOrdering] = useState(false);

  useEffect(() => {
    api.get(`/gigs/${slug}`)
      .then(res => setGig(res.data.data))
      .catch(() => navigate('/gigs'))
      .finally(() => setLoading(false));
  }, [slug, navigate]);

  const handleOrder = async () => {
    if (!user) return navigate('/login', { state: { from: `/gigs/${slug}` } });
    if (user.role === 'freelancer') return toast.error("Freelancers can't place orders");
    setOrdering(true);
    try {
      const pkg = gig.packages[selPkg];
      const res = await api.post('/orders', {
        gig_id: gig.gig_id, package_id: pkg.package_id, requirements: '',
      });
      toast.success('Order placed! Complete payment to activate.');
      navigate(`/orders/${res.data.data.order_id}`);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to place order');
    } finally {
      setOrdering(false);
    }
  };

  if (loading) return <div className="flex items-center justify-center min-h-screen text-green-600 text-xl">Loading...</div>;
  if (!gig)   return null;

  const pkg = gig.packages?.[selPkg];

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navbar />
      <div className="max-w-6xl mx-auto px-4 py-8 w-full">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* LEFT — gig info */}
          <div className="flex-1">
            <p className="text-sm text-gray-500 mb-2">
              <Link to="/gigs" className="text-green-600 hover:underline">Services</Link>
              {' › '}{gig.category_name}{' › '}{gig.title}
            </p>
            <h1 className="text-2xl font-bold text-gray-900 mb-4">{gig.title}</h1>

            {/* Seller info */}
            <div className="flex items-center gap-3 mb-5">
              {gig.avatar_url
                ? <img src={gig.avatar_url} className="w-10 h-10 rounded-full" alt="" />
                : <div className="w-10 h-10 rounded-full bg-green-200 flex items-center justify-center font-bold text-green-700">
                    {gig.first_name?.[0]}
                  </div>
              }
              <div>
                <Link to={`/freelancers/${gig.username}`} className="font-semibold text-gray-800 hover:text-green-600">
                  {gig.first_name} {gig.last_name}
                </Link>
                {gig.tagline && <p className="text-xs text-gray-500">{gig.tagline}</p>}
              </div>
              {gig.avg_rating > 0 && (
                <span className="text-sm text-yellow-500 ml-auto">
                  ⭐ {Number(gig.avg_rating).toFixed(1)} ({gig.total_reviews} reviews)
                </span>
              )}
            </div>

            {/* Gig images */}
            {gig.images?.length > 0 && (
              <div className="rounded-xl overflow-hidden mb-6 h-64 bg-gray-200">
                <img src={gig.images[0].image_url} alt={gig.title} className="w-full h-full object-cover" />
              </div>
            )}

            {/* Description */}
            <div className="bg-white rounded-xl p-6 border border-gray-100 mb-6">
              <h2 className="font-bold text-lg mb-3">About This Service</h2>
              <p className="text-gray-600 text-sm leading-relaxed whitespace-pre-line">{gig.description}</p>
            </div>

            {/* Reviews */}
            {gig.reviews?.length > 0 && (
              <div className="bg-white rounded-xl p-6 border border-gray-100">
                <h2 className="font-bold text-lg mb-4">Client Reviews</h2>
                <div className="space-y-4">
                  {gig.reviews.map((r, i) => (
                    <div key={i} className="border-b border-gray-50 pb-4 last:border-0">
                      <div className="flex items-center gap-2 mb-1">
                        <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center text-xs font-bold text-green-700">
                          {r.first_name?.[0]}
                        </div>
                        <span className="text-sm font-medium">{r.first_name}</span>
                        <span className="text-yellow-400 text-xs">{'⭐'.repeat(r.rating)}</span>
                        <span className="text-gray-400 text-xs ml-auto">
                          {new Date(r.created_at).toLocaleDateString()}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 pl-10">{r.comment}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* RIGHT — order panel */}
          <div className="lg:w-80 flex-shrink-0">
            <div className="bg-white rounded-2xl border border-gray-200 shadow-sm sticky top-20">
              {/* Package tabs */}
              {gig.packages?.length > 1 && (
                <div className="flex border-b border-gray-100">
                  {gig.packages.map((p, i) => (
                    <button key={i} onClick={() => setSelPkg(i)}
                      className={`flex-1 py-3 text-xs font-semibold capitalize transition ${
                        selPkg === i ? 'border-b-2 border-green-600 text-green-700' : 'text-gray-500 hover:text-gray-700'
                      }`}>
                      {p.tier}
                    </button>
                  ))}
                </div>
              )}

              {pkg && (
                <div className="p-5">
                  <div className="flex justify-between items-center mb-3">
                    <span className="font-bold text-lg">{pkg.title}</span>
                    <span className="font-extrabold text-xl text-green-700">
                      {pkg.currency} {Number(pkg.price).toLocaleString()}
                    </span>
                  </div>
                  <p className="text-sm text-gray-500 mb-4">{pkg.description}</p>
                  <div className="space-y-2 text-sm text-gray-600 mb-5">
                    <div className="flex gap-2"><span>⏱</span><span>{pkg.delivery_days} day delivery</span></div>
                    <div className="flex gap-2"><span>🔄</span><span>{pkg.revisions} revision{pkg.revisions !== 1 ? 's' : ''}</span></div>
                  </div>
                  <button onClick={handleOrder} disabled={ordering}
                    className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 rounded-xl transition disabled:opacity-50">
                    {ordering ? 'Placing order...' : 'Continue →'}
                  </button>
                  <p className="text-xs text-gray-400 text-center mt-2">Payment held in escrow until delivery</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
