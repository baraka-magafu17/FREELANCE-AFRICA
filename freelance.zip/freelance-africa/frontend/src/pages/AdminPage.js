// src/pages/AdminPage.js
import React, { useEffect, useState } from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import api from '../utils/api';
import Navbar from '../components/common/Navbar';
import toast from 'react-hot-toast';

// ── Overview tab ──────────────────────────────────────
function AdminOverview() {
  const [stats, setStats] = useState(null);
  useEffect(() => { api.get('/admin/stats').then(res => setStats(res.data.data)); }, []);
  if (!stats) return <div className="text-gray-400 py-8 text-center">Loading stats...</div>;

  const cards = [
    { label: 'Total Users',     value: stats.totals.users,    icon: '👥' },
    { label: 'Active Gigs',     value: stats.totals.gigs,     icon: '💼' },
    { label: 'Total Orders',    value: stats.totals.orders,   icon: '📦' },
    { label: 'Revenue Released',value: `$${Number(stats.totals.revenue).toLocaleString()}`, icon: '💰' },
    { label: 'Pending Orders',  value: stats.totals.pending_orders, icon: '⏳' },
    { label: 'Open Disputes',   value: stats.totals.disputes, icon: '⚠️' },
  ];

  return (
    <div>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
        {cards.map(c => (
          <div key={c.label} className="bg-white rounded-xl p-5 border border-gray-100 shadow-sm">
            <div className="text-2xl mb-1">{c.icon}</div>
            <div className="font-bold text-xl text-gray-800">{c.value}</div>
            <div className="text-xs text-gray-500 mt-1">{c.label}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
          <h3 className="font-bold text-gray-800 mb-4">Orders by Status</h3>
          <div className="space-y-2">
            {stats.orders_by_status.map(o => (
              <div key={o.status} className="flex items-center justify-between text-sm">
                <span className="capitalize text-gray-600">{o.status.replace('_', ' ')}</span>
                <span className="font-semibold">{o.count}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
          <h3 className="font-bold text-gray-800 mb-4">Top Freelancers</h3>
          <div className="space-y-3">
            {stats.top_freelancers.map((f, i) => (
              <div key={i} className="flex items-center gap-3 text-sm">
                <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center font-bold text-green-700 text-xs">
                  {f.username?.[0]?.toUpperCase()}
                </div>
                <span className="flex-1 font-medium text-gray-700">{f.username}</span>
                <span className="text-yellow-500">⭐ {f.avg_rating}</span>
                <span className="text-gray-400 text-xs">{f.total_orders} orders</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Users tab ────────────────────────────────────────
function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchUsers = () => api.get('/admin/users').then(res => setUsers(res.data.data)).finally(() => setLoading(false));
  useEffect(() => { fetchUsers(); }, []);

  const toggle = async (id) => {
    try {
      await api.put(`/admin/users/${id}/toggle`);
      toast.success('User status updated');
      fetchUsers();
    } catch { toast.error('Failed to update user'); }
  };

  if (loading) return <div className="text-gray-400 py-8 text-center">Loading users...</div>;

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
      <table className="w-full text-sm">
        <thead className="bg-gray-50 text-gray-500 text-left">
          <tr>
            <th className="px-4 py-3">Name</th>
            <th className="px-4 py-3">Email</th>
            <th className="px-4 py-3">Role</th>
            <th className="px-4 py-3">Status</th>
            <th className="px-4 py-3">Joined</th>
            <th className="px-4 py-3"></th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-50">
          {users.map(u => (
            <tr key={u.user_id}>
              <td className="px-4 py-3 font-medium text-gray-800">{u.first_name} {u.last_name}</td>
              <td className="px-4 py-3 text-gray-500">{u.email}</td>
              <td className="px-4 py-3 capitalize text-gray-600">{u.role}</td>
              <td className="px-4 py-3">
                <span className={`px-2 py-1 rounded-full text-xs font-semibold ${u.is_active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                  {u.is_active ? 'Active' : 'Disabled'}
                </span>
              </td>
              <td className="px-4 py-3 text-gray-400">{new Date(u.created_at).toLocaleDateString()}</td>
              <td className="px-4 py-3 text-right">
                <button onClick={() => toggle(u.user_id)} className="text-xs font-semibold text-green-600 hover:underline">
                  {u.is_active ? 'Disable' : 'Enable'}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ── Disputes tab ──────────────────────────────────────
function AdminDisputes() {
  const [disputes, setDisputes] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchDisputes = () => api.get('/admin/disputes?status=open').then(res => setDisputes(res.data.data)).finally(() => setLoading(false));
  useEffect(() => { fetchDisputes(); }, []);

  const resolve = async (id, resolution) => {
    try {
      await api.put(`/admin/disputes/${id}/resolve`, { resolution, admin_notes: 'Resolved by admin' });
      toast.success('Dispute resolved');
      fetchDisputes();
    } catch { toast.error('Failed to resolve dispute'); }
  };

  if (loading) return <div className="text-gray-400 py-8 text-center">Loading disputes...</div>;
  if (disputes.length === 0) return <div className="text-center py-12 text-gray-400">🎉 No open disputes</div>;

  return (
    <div className="space-y-4">
      {disputes.map(d => (
        <div key={d.dispute_id} className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
          <div className="flex justify-between items-start mb-2">
            <div>
              <p className="font-semibold text-gray-800">{d.order_ref}</p>
              <p className="text-xs text-gray-400">
                Client: {d.client_username} · Freelancer: {d.freelancer_username} · {d.currency} {Number(d.amount).toLocaleString()}
              </p>
            </div>
            <span className="text-xs font-semibold px-2 py-1 rounded-full bg-red-100 text-red-700">Open</span>
          </div>
          <p className="text-sm text-gray-600 mb-3">Raised by <strong>{d.raised_by_username}</strong>: {d.reason}</p>
          <div className="flex gap-2">
            <button onClick={() => resolve(d.dispute_id, 'resolved_client')}
              className="text-xs font-semibold bg-blue-50 text-blue-700 px-4 py-2 rounded-lg hover:bg-blue-100 transition">
              Refund Client
            </button>
            <button onClick={() => resolve(d.dispute_id, 'resolved_freelancer')}
              className="text-xs font-semibold bg-green-50 text-green-700 px-4 py-2 rounded-lg hover:bg-green-100 transition">
              Pay Freelancer
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}

// ── Main Admin layout ─────────────────────────────────
export default function AdminPage() {
  const location = useLocation();
  const tabs = [
    { label: 'Overview', path: '/admin' },
    { label: 'Users',    path: '/admin/users' },
    { label: 'Disputes', path: '/admin/disputes' },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="max-w-6xl mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold text-gray-800 mb-6">Admin Panel</h1>
        <div className="flex gap-2 mb-6 border-b border-gray-200">
          {tabs.map(tab => (
            <Link key={tab.path} to={tab.path}
              className={`px-4 py-2 text-sm font-semibold border-b-2 transition ${
                location.pathname === tab.path ? 'border-green-600 text-green-700' : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}>
              {tab.label}
            </Link>
          ))}
        </div>
        <Routes>
          <Route index            element={<AdminOverview />} />
          <Route path="users"     element={<AdminUsers />} />
          <Route path="disputes"  element={<AdminDisputes />} />
        </Routes>
      </div>
    </div>
  );
}
