// src/pages/HomePage.js
import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from '../utils/api';
import Navbar from '../components/common/Navbar';
import Footer from '../components/common/Footer';
import GigCard from '../components/gigs/GigCard';

const CATEGORIES = [
  { name: 'Graphic Design',       slug: 'graphic-design',       icon: '🎨' },
  { name: 'Writing & Content',    slug: 'writing-content',      icon: '✍️' },
  { name: 'Software Development', slug: 'software-dev',         icon: '💻' },
  { name: 'Digital Marketing',    slug: 'digital-marketing',    icon: '📣' },
  { name: 'Video & Animation',    slug: 'video-animation',      icon: '🎬' },
  { name: 'Data & Analytics',     slug: 'data-analytics',       icon: '📊' },
  { name: 'Music & Audio',        slug: 'music-audio',          icon: '🎵' },
  { name: 'Business Consulting',  slug: 'business-consulting',  icon: '💼' },
];

export default function HomePage() {
  const [featuredGigs, setFeaturedGigs] = useState([]);
  const [searchQuery,  setSearchQuery]  = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    api.get('/gigs?limit=8')
      .then(res => setFeaturedGigs(res.data.data || []))
      .catch(() => {});
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) navigate(`/gigs?keyword=${encodeURIComponent(searchQuery)}`);
  };

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navbar />

      {/* ── HERO ── */}
      <section className="bg-gradient-to-br from-green-700 to-green-900 text-white py-24 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl font-extrabold mb-4 leading-tight">
            Africa's Freelance Marketplace
          </h1>
          <p className="text-xl mb-10 text-green-100">
            Connect with talented African freelancers. Pay with M-Pesa or Flutterwave.
            No currency loss. No barriers.
          </p>
          <form onSubmit={handleSearch} className="flex max-w-2xl mx-auto shadow-xl rounded-full overflow-hidden">
            <input
              type="text"
              placeholder='Search for "logo design", "web development"...'
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="flex-1 px-6 py-4 text-gray-800 text-lg focus:outline-none"
            />
            <button
              type="submit"
              className="bg-yellow-400 hover:bg-yellow-300 text-gray-900 font-bold px-8 text-lg transition"
            >
              Search
            </button>
          </form>
          <p className="mt-4 text-green-200 text-sm">
            Popular: Graphic Design · Web Development · Content Writing · SEO
          </p>
        </div>
      </section>

      {/* ── STATS BANNER ── */}
      <section className="bg-green-50 border-b border-green-100 py-8">
        <div className="max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6 text-center px-6">
          {[
            { label: 'Freelancers', value: '2,400+' },
            { label: 'Services',    value: '8,000+' },
            { label: 'Orders Done', value: '15,000+' },
            { label: 'Countries',   value: 'TZ · KE · NG' },
          ].map(stat => (
            <div key={stat.label}>
              <div className="text-3xl font-extrabold text-green-700">{stat.value}</div>
              <div className="text-gray-500 text-sm mt-1">{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ── CATEGORIES ── */}
      <section className="py-16 px-6 max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold text-gray-800 mb-8 text-center">Browse by Category</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {CATEGORIES.map(cat => (
            <Link
              key={cat.slug}
              to={`/gigs?category=${cat.slug}`}
              className="flex flex-col items-center p-5 rounded-xl border-2 border-gray-100 hover:border-green-500 hover:bg-green-50 transition group"
            >
              <span className="text-4xl mb-2">{cat.icon}</span>
              <span className="text-sm font-semibold text-gray-700 group-hover:text-green-700 text-center">
                {cat.name}
              </span>
            </Link>
          ))}
        </div>
      </section>

      {/* ── FEATURED GIGS ── */}
      <section className="py-12 px-6 max-w-6xl mx-auto w-full">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold text-gray-800">Top Services</h2>
          <Link to="/gigs" className="text-green-600 font-semibold hover:underline">
            View all →
          </Link>
        </div>
        {featuredGigs.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredGigs.map(gig => <GigCard key={gig.gig_id} gig={gig} />)}
          </div>
        ) : (
          <div className="text-center py-12 text-gray-400">Loading gigs...</div>
        )}
      </section>

      {/* ── HOW IT WORKS ── */}
      <section className="bg-gray-50 py-16 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-gray-800 mb-10">How FreelanceAfrica Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { step: '1', title: 'Find a Service',  desc: 'Browse hundreds of verified African freelancers by skill, rating, or budget.', icon: '🔍' },
              { step: '2', title: 'Pay Securely',    desc: 'Pay with M-Pesa or Flutterwave. Funds are held in escrow until work is done.', icon: '🔒' },
              { step: '3', title: 'Get Your Work',   desc: 'Receive your delivery, request revisions, and release payment when satisfied.', icon: '✅' },
            ].map(item => (
              <div key={item.step} className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
                <div className="text-4xl mb-4">{item.icon}</div>
                <div className="w-8 h-8 bg-green-600 text-white rounded-full flex items-center justify-center font-bold text-sm mx-auto mb-3">
                  {item.step}
                </div>
                <h3 className="font-bold text-lg mb-2">{item.title}</h3>
                <p className="text-gray-500 text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="bg-green-700 text-white py-16 px-6 text-center">
        <h2 className="text-3xl font-bold mb-4">Ready to get started?</h2>
        <p className="text-green-200 mb-8 max-w-xl mx-auto">
          Join thousands of African freelancers and clients already using FreelanceAfrica.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link to="/register?role=freelancer"
            className="bg-white text-green-700 font-bold py-3 px-8 rounded-full hover:bg-green-50 transition">
            Become a Freelancer
          </Link>
          <Link to="/register?role=client"
            className="border-2 border-white text-white font-bold py-3 px-8 rounded-full hover:bg-green-600 transition">
            Hire a Freelancer
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
}
