// src/pages/DashboardPage.js
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import Navbar from '../components/common/Navbar';

export default function DashboardPage() {
  const { user }  = useAuth();
  const [orders, setOrders]   = useState([]);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      api.get('/orders?limit=5'),
      api.get('/users/me'),
    ]).then(([ordRes, userRes]) => {
      setOrders(ordRes.data.data || []);
      setProfile(userRes.data.data);
    }).finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="flex items-center justify-center min-h-screen text-green-600">Loading...</div>;

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="max-w-5xl mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold text-gray-800 mb-6">Welcome back, {user?.first_name} 👋</h1>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Balance',      value: `${profile?.currency || 'USD'} ${Number(profile?.balance || 0).toLocaleString()}`, icon: '💰' },
            { label: 'Total Earned', value: `${Number(profile?.total_earned || 0).toLocaleString()}`,   icon: '📈' },
            { label: 'Total Orders', value: profile?.total_orders || 0,   icon: '📦' },
            { label: 'Avg Rating',   value: profile?.avg_rating ? `⭐ ${profile.avg_rating}` : 'N/A', icon: '⭐' },
          ].map(stat => (
            <div key={stat.label} className="bg-white rounded-xl p-5 border border-gray-100 shadow-sm">
              <div className="text-2xl mb-1">{stat.icon}</div>
              <div className="font-bold text-xl text-gray-800">{stat.value}</div>
              <div className="text-xs text-gray-500 mt-1">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Recent orders */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="font-bold text-lg text-gray-800">Recent Orders</h2>
            <Link to="/orders" className="text-green-600 text-sm hover:underline">View all →</Link>
          </div>
          {orders.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              <p>No orders yet.</p>
              {user?.role === 'client' && (
                <Link to="/gigs" className="text-green-600 font-semibold hover:underline mt-2 block">
                  Browse services →
                </Link>
              )}
            </div>
          ) : (
            <div className="space-y-3">
              {orders.map(order => (
                <Link key={order.order_id} to={`/orders/${order.order_id}`}
                  className="flex items-center gap-4 p-3 rounded-xl hover:bg-gray-50 transition">
                  <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center text-lg">📦</div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm text-gray-800 truncate">{order.gig_title}</p>
                    <p className="text-xs text-gray-400">{order.order_ref}</p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <span className="text-xs font-semibold capitalize px-2 py-1 rounded-full bg-green-50 text-green-700">
                      {order.status.replace('_', ' ')}
                    </span>
                    <p className="text-xs text-gray-500 mt-1">{order.currency} {Number(order.amount).toLocaleString()}</p>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
