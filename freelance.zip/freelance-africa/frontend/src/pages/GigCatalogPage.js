// src/pages/GigCatalogPage.js
import React, { useEffect, useState, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import api from '../utils/api';
import Navbar from '../components/common/Navbar';
import Footer from '../components/common/Footer';
import GigCard from '../components/gigs/GigCard';

const CATEGORIES = [
  { name: 'All',                  slug: '' },
  { name: 'Graphic Design',       slug: 'graphic-design' },
  { name: 'Writing & Content',    slug: 'writing-content' },
  { name: 'Software Development', slug: 'software-dev' },
  { name: 'Digital Marketing',    slug: 'digital-marketing' },
  { name: 'Video & Animation',    slug: 'video-animation' },
  { name: 'Data & Analytics',     slug: 'data-analytics' },
  { name: 'Music & Audio',        slug: 'music-audio' },
  { name: 'Business Consulting',  slug: 'business-consulting' },
];

export default function GigCatalogPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [gigs,       setGigs]       = useState([]);
  const [pagination, setPagination] = useState({});
  const [loading,    setLoading]    = useState(true);

  const keyword      = searchParams.get('keyword') || '';
  const category     = searchParams.get('category') || '';
  const minRating    = searchParams.get('min_rating') || '';
  const deliveryDays = searchParams.get('delivery_days') || '';
  const page         = searchParams.get('page') || 1;

  const fetchGigs = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (keyword)      params.set('keyword',       keyword);
      if (category)     params.set('category',      category);
      if (minRating)    params.set('min_rating',    minRating);
      if (deliveryDays) params.set('delivery_days', deliveryDays);
      params.set('page',  page);
      params.set('limit', 12);

      const res = await api.get(`/gigs?${params}`);
      setGigs(res.data.data || []);
      setPagination(res.data.pagination || {});
    } catch {
      setGigs([]);
    } finally {
      setLoading(false);
    }
  }, [keyword, category, minRating, deliveryDays, page]);

  useEffect(() => { fetchGigs(); }, [fetchGigs]);

  const updateFilter = (key, value) => {
    const p = new URLSearchParams(searchParams);
    if (value) p.set(key, value); else p.delete(key);
    p.delete('page');
    setSearchParams(p);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 py-8 w-full flex-1">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-800">
            {keyword ? `Results for "${keyword}"` : category ? `${CATEGORIES.find(c => c.slug === category)?.name || 'Services'}` : 'Browse All Services'}
          </h1>
          {pagination.total !== undefined && (
            <p className="text-gray-500 text-sm mt-1">{pagination.total} services found</p>
          )}
        </div>

        <div className="flex flex-col lg:flex-row gap-6">
          {/* Sidebar Filters */}
          <aside className="lg:w-56 space-y-6 flex-shrink-0">
            <div>
              <h3 className="font-semibold text-gray-700 mb-3 text-sm uppercase tracking-wide">Category</h3>
              <ul className="space-y-1">
                {CATEGORIES.map(cat => (
                  <li key={cat.slug}>
                    <button
                      onClick={() => updateFilter('category', cat.slug)}
                      className={`w-full text-left text-sm px-3 py-2 rounded-lg transition ${
                        category === cat.slug
                          ? 'bg-green-600 text-white font-semibold'
                          : 'text-gray-600 hover:bg-gray-100'
                      }`}
                    >
                      {cat.name}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="font-semibold text-gray-700 mb-3 text-sm uppercase tracking-wide">Delivery Time</h3>
              {[['Any', ''], ['Up to 3 days', '3'], ['Up to 7 days', '7'], ['Up to 14 days', '14']].map(([label, val]) => (
                <label key={val} className="flex items-center gap-2 text-sm py-1 cursor-pointer text-gray-600 hover:text-green-700">
                  <input type="radio" name="delivery" checked={deliveryDays === val}
                    onChange={() => updateFilter('delivery_days', val)} />
                  {label}
                </label>
              ))}
            </div>

            <div>
              <h3 className="font-semibold text-gray-700 mb-3 text-sm uppercase tracking-wide">Min Rating</h3>
              {[['Any', ''], ['4.5+', '4.5'], ['4.0+', '4.0'], ['3.5+', '3.5']].map(([label, val]) => (
                <label key={val} className="flex items-center gap-2 text-sm py-1 cursor-pointer text-gray-600 hover:text-green-700">
                  <input type="radio" name="rating" checked={minRating === val}
                    onChange={() => updateFilter('min_rating', val)} />
                  {label}
                </label>
              ))}
            </div>
          </aside>

          {/* Gig Grid */}
          <div className="flex-1">
            {loading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="h-64 bg-gray-200 rounded-xl animate-pulse" />
                ))}
              </div>
            ) : gigs.length > 0 ? (
              <>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                  {gigs.map(gig => <GigCard key={gig.gig_id} gig={gig} />)}
                </div>
                {/* Pagination */}
                {pagination.pages > 1 && (
                  <div className="flex justify-center gap-2 mt-8">
                    {[...Array(pagination.pages)].map((_, i) => (
                      <button key={i}
                        onClick={() => updateFilter('page', i + 1)}
                        className={`w-9 h-9 rounded-full text-sm font-semibold transition ${
                          Number(page) === i + 1
                            ? 'bg-green-600 text-white'
                            : 'bg-white border border-gray-200 text-gray-600 hover:border-green-500'
                        }`}
                      >
                        {i + 1}
                      </button>
                    ))}
                  </div>
                )}
              </>
            ) : (
              <div className="text-center py-16 text-gray-400">
                <div className="text-5xl mb-4">🔍</div>
                <p className="text-lg font-medium">No services found</p>
                <p className="text-sm mt-1">Try adjusting your filters or search terms</p>
              </div>
            )}
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
