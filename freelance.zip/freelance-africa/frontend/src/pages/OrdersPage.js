// src/pages/OrdersPage.js
import React, { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import api from '../utils/api';
import Navbar from '../components/common/Navbar';

const STATUSES = ['', 'pending', 'active', 'delivered', 'completed', 'cancelled'];

export default function OrdersPage() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [params, setParams] = useSearchParams();
  const status = params.get('status') || '';

  useEffect(() => {
    setLoading(true);
    api.get(`/orders${status ? `?status=${status}` : ''}`)
      .then(res => setOrders(res.data.data || []))
      .finally(() => setLoading(false));
  }, [status]);

  const STATUS_COLORS = {
    pending: 'bg-yellow-100 text-yellow-700', active: 'bg-blue-100 text-blue-700',
    delivered: 'bg-purple-100 text-purple-700', completed: 'bg-green-100 text-green-700',
    cancelled: 'bg-gray-100 text-gray-500', disputed: 'bg-red-100 text-red-700',
    revision_requested: 'bg-orange-100 text-orange-700',
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="max-w-4xl mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold mb-6 text-gray-800">My Orders</h1>
        <div className="flex gap-2 mb-6 flex-wrap">
          {STATUSES.map(s => (
            <button key={s} onClick={() => { const p = new URLSearchParams(); if (s) p.set('status', s); setParams(p); }}
              className={`px-4 py-1.5 rounded-full text-sm font-medium capitalize transition ${
                status === s ? 'bg-green-600 text-white' : 'bg-white border border-gray-200 text-gray-600 hover:border-green-400'
              }`}>
              {s || 'All'}
            </button>
          ))}
        </div>
        {loading ? <div className="text-center py-16 text-gray-400">Loading orders...</div> : (
          orders.length === 0 ? (
            <div className="text-center py-16 text-gray-400">
              <div className="text-5xl mb-4">📭</div>
              <p>No orders found</p>
              <Link to="/gigs" className="text-green-600 hover:underline mt-2 block">Browse services</Link>
            </div>
          ) : (
            <div className="space-y-3">
              {orders.map(order => (
                <Link key={order.order_id} to={`/orders/${order.order_id}`}
                  className="block bg-white rounded-xl border border-gray-100 p-5 hover:shadow-sm transition">
                  <div className="flex items-start justify-between gap-4">
                    <div className="min-w-0 flex-1">
                      <p className="font-semibold text-gray-800 truncate">{order.gig_title}</p>
                      <p className="text-xs text-gray-400 mt-1">{order.order_ref} · Due {new Date(order.due_date).toLocaleDateString()}</p>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <span className={`text-xs font-semibold px-2 py-1 rounded-full capitalize ${STATUS_COLORS[order.status] || ''}`}>
                        {order.status.replace('_', ' ')}
                      </span>
                      <p className="font-bold text-sm text-gray-800 mt-1">{order.currency} {Number(order.amount).toLocaleString()}</p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )
        )}
      </div>
    </div>
  );
}
