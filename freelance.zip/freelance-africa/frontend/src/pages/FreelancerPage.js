// src/pages/FreelancerPage.js
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../utils/api';
import Navbar from '../components/common/Navbar';
import GigCard from '../components/gigs/GigCard';

export default function FreelancerPage() {
  const { username } = useParams();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get(`/users/${username}`)
      .then(res => setProfile(res.data.data))
      .finally(() => setLoading(false));
  }, [username]);

  if (loading) return <div className="flex items-center justify-center min-h-screen text-green-600">Loading...</div>;
  if (!profile) return <div className="text-center py-20">Freelancer not found</div>;

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="max-w-5xl mx-auto px-4 py-10">
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-8 mb-8 flex flex-col sm:flex-row gap-6 items-start">
          {profile.avatar_url
            ? <img src={profile.avatar_url} className="w-24 h-24 rounded-full object-cover" alt="" />
            : <div className="w-24 h-24 rounded-full bg-green-200 flex items-center justify-center text-4xl font-bold text-green-700">
                {profile.first_name?.[0]}
              </div>
          }
          <div className="flex-1">
            <h1 className="text-2xl font-bold">{profile.first_name} {profile.last_name}</h1>
            <p className="text-gray-500 text-sm">@{profile.username} · {profile.country_name}</p>
            {profile.tagline && <p className="mt-2 text-gray-700">{profile.tagline}</p>}
            <div className="flex gap-6 mt-4 text-sm text-gray-600">
              {profile.avg_rating > 0 && <span>⭐ {Number(profile.avg_rating).toFixed(1)} ({profile.total_reviews} reviews)</span>}
              <span>📦 {profile.total_orders || 0} orders</span>
              {profile.response_time_hrs && <span>⏱ {profile.response_time_hrs}h response</span>}
              <span className={`capitalize font-medium ${profile.availability === 'available' ? 'text-green-600' : 'text-gray-400'}`}>
                ● {profile.availability}
              </span>
            </div>
          </div>
        </div>

        {profile.gigs?.length > 0 && (
          <div>
            <h2 className="text-xl font-bold mb-4">Services Offered</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {profile.gigs.map(gig => <GigCard key={gig.gig_id} gig={gig} />)}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
