// src/App.js
import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './context/AuthContext';

// Pages
import HomePage        from './pages/HomePage';
import LoginPage       from './pages/LoginPage';
import RegisterPage    from './pages/RegisterPage';
import VerifyEmailPage from './pages/VerifyEmailPage';
import GigCatalogPage  from './pages/GigCatalogPage';
import GigDetailPage   from './pages/GigDetailPage';
import FreelancerPage  from './pages/FreelancerPage';
import OrdersPage      from './pages/OrdersPage';
import OrderDetailPage from './pages/OrderDetailPage';
import DashboardPage   from './pages/DashboardPage';
import AdminPage       from './pages/AdminPage';
import NotFoundPage    from './pages/NotFoundPage';

// Protected route wrapper
const PrivateRoute = ({ children, roles }) => {
  const { user, loading } = useAuth();
  if (loading) return <div className="flex items-center justify-center min-h-screen"><div className="spinner" /></div>;
  if (!user)   return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to="/" replace />;
  return children;
};

const AppRoutes = () => (
  <Routes>
    {/* Public */}
    <Route path="/"                   element={<HomePage />} />
    <Route path="/login"              element={<LoginPage />} />
    <Route path="/register"           element={<RegisterPage />} />
    <Route path="/verify-email/:token" element={<VerifyEmailPage />} />
    <Route path="/gigs"               element={<GigCatalogPage />} />
    <Route path="/gigs/:slug"         element={<GigDetailPage />} />
    <Route path="/freelancers/:username" element={<FreelancerPage />} />

    {/* Protected — any logged-in user */}
    <Route path="/dashboard" element={
      <PrivateRoute><DashboardPage /></PrivateRoute>
    } />
    <Route path="/orders" element={
      <PrivateRoute><OrdersPage /></PrivateRoute>
    } />
    <Route path="/orders/:id" element={
      <PrivateRoute><OrderDetailPage /></PrivateRoute>
    } />

    {/* Admin only */}
    <Route path="/admin/*" element={
      <PrivateRoute roles={['admin']}><AdminPage /></PrivateRoute>
    } />

    <Route path="*" element={<NotFoundPage />} />
  </Routes>
);

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Toaster position="top-right" toastOptions={{ duration: 4000 }} />
        <AppRoutes />
      </BrowserRouter>
    </AuthProvider>
  );
}
