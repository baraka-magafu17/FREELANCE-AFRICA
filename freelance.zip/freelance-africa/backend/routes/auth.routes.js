// routes/auth.routes.js
const express = require('express');
const router  = express.Router();
const { register, login, verifyEmail, refreshToken, logout } = require('../controllers/auth.controller');
const { authenticate } = require('../middleware/auth.middleware');

router.post('/register',        register);
router.post('/login',           login);
router.get ('/verify/:token',   verifyEmail);
router.post('/refresh',         refreshToken);
router.post('/logout',          authenticate, logout);

module.exports = router;
