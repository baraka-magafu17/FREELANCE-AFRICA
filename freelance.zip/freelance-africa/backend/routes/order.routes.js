// routes/order.routes.js
const express = require('express');
const router  = express.Router();
const {
  createOrder, getMyOrders, getOrderById,
  deliverOrder, completeOrder, requestRevision, cancelOrder,
} = require('../controllers/order.controller');
const { authenticate, authorize } = require('../middleware/auth.middleware');

router.post('/',                     authenticate, authorize('client'), createOrder);
router.get ('/',                     authenticate, getMyOrders);
router.get ('/:id',                  authenticate, getOrderById);
router.put ('/:id/deliver',          authenticate, authorize('freelancer'), deliverOrder);
router.put ('/:id/complete',         authenticate, authorize('client'), completeOrder);
router.put ('/:id/revision',         authenticate, authorize('client'), requestRevision);
router.put ('/:id/cancel',           authenticate, cancelOrder);

module.exports = router;
