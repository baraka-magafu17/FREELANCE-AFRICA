// routes/payment.routes.js
const express = require('express');
const router  = express.Router();
const {
  mpesaStkPush, mpesaCallback,
  flutterwaveInitiate, flutterwaveWebhook,
  getPaymentStatus,
} = require('../controllers/payment.controller');
const { authenticate } = require('../middleware/auth.middleware');

router.post('/mpesa/stk-push',         authenticate, mpesaStkPush);
router.post('/mpesa/callback',         mpesaCallback);          // public — called by Safaricom
router.post('/flutterwave/initiate',   authenticate, flutterwaveInitiate);
router.post('/flutterwave/webhook',    flutterwaveWebhook);     // public — called by Flutterwave
router.get ('/order/:order_id',        authenticate, getPaymentStatus);

module.exports = router;
