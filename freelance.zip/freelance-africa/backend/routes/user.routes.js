// routes/user.routes.js
const express = require('express');
const router  = express.Router();
const db      = require('../config/db');
const { authenticate } = require('../middleware/auth.middleware');

// GET /api/users/me — Current user profile
router.get('/me', authenticate, async (req, res) => {
  try {
    const [rows] = await db.execute(
      `SELECT u.user_id, u.first_name, u.last_name, u.username, u.email, u.role,
              u.avatar_url, u.bio, u.phone_number, u.created_at,
              c.country_name, c.currency,
              w.balance, w.total_earned,
              fp.tagline, fp.avg_rating, fp.total_orders, fp.availability,
              fp.languages, fp.years_experience
       FROM users u
       LEFT JOIN countries c ON u.country_id = c.country_id
       LEFT JOIN wallets w ON u.user_id = w.user_id
       LEFT JOIN freelancer_profiles fp ON u.user_id = fp.user_id
       WHERE u.user_id = ?`,
      [req.user.user_id]
    );
    if (!rows.length) return res.status(404).json({ success: false, message: 'User not found' });
    res.json({ success: true, data: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch profile' });
  }
});

// GET /api/users/:username — Public profile
router.get('/:username', async (req, res) => {
  try {
    const [rows] = await db.execute(
      `SELECT u.user_id, u.first_name, u.last_name, u.username, u.avatar_url,
              u.bio, u.role, u.created_at,
              c.country_name,
              fp.tagline, fp.avg_rating, fp.total_orders, fp.total_reviews,
              fp.completion_rate, fp.response_time_hrs, fp.languages,
              fp.years_experience, fp.portfolio_url, fp.availability
       FROM users u
       LEFT JOIN countries c ON u.country_id = c.country_id
       LEFT JOIN freelancer_profiles fp ON u.user_id = fp.user_id
       WHERE u.username = ? AND u.is_active = 1`,
      [req.params.username]
    );
    if (!rows.length) return res.status(404).json({ success: false, message: 'User not found' });

    const user = rows[0];

    // Fetch their active gigs if freelancer
    let gigs = [];
    if (user.role === 'freelancer') {
      [gigs] = await db.execute(
        `SELECT g.gig_id, g.title, g.slug, g.thumbnail_url, g.avg_rating, g.total_orders,
                MIN(p.price) AS starting_price, MIN(p.currency) AS currency
         FROM gigs g
         LEFT JOIN gig_packages p ON g.gig_id = p.gig_id AND p.tier = 'basic'
         WHERE g.freelancer_id = ? AND g.status = 'active'
         GROUP BY g.gig_id LIMIT 10`,
        [user.user_id]
      );
    }

    res.json({ success: true, data: { ...user, gigs } });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch profile' });
  }
});

// PUT /api/users/me — Update own profile
router.put('/me', authenticate, async (req, res) => {
  try {
    const { first_name, last_name, bio, avatar_url, phone_number,
            tagline, languages, years_experience, availability } = req.body;

    await db.execute(
      'UPDATE users SET first_name=?, last_name=?, bio=?, avatar_url=?, phone_number=?, updated_at=NOW() WHERE user_id=?',
      [first_name, last_name, bio, avatar_url, phone_number, req.user.user_id]
    );

    if (req.user.role === 'freelancer') {
      await db.execute(
        'UPDATE freelancer_profiles SET tagline=?, languages=?, years_experience=?, availability=?, updated_at=NOW() WHERE user_id=?',
        [tagline, languages, years_experience, availability, req.user.user_id]
      );
    }

    res.json({ success: true, message: 'Profile updated successfully' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to update profile' });
  }
});

// GET /api/users/me/notifications
router.get('/me/notifications', authenticate, async (req, res) => {
  try {
    const [notifs] = await db.execute(
      'SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 20',
      [req.user.user_id]
    );
    res.json({ success: true, data: notifs });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch notifications' });
  }
});

module.exports = router;
