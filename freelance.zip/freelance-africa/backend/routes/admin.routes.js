// routes/admin.routes.js
const express = require('express');
const router  = express.Router();
const {
  getDashboardStats, getAllUsers, toggleUserStatus,
  getDisputes, resolveDispute,
} = require('../controllers/admin.controller');
const { authenticate, authorize } = require('../middleware/auth.middleware');

// All admin routes require admin role
router.use(authenticate, authorize('admin'));

router.get ('/stats',                 getDashboardStats);
router.get ('/users',                 getAllUsers);
router.put ('/users/:id/toggle',      toggleUserStatus);
router.get ('/disputes',              getDisputes);
router.put ('/disputes/:id/resolve',  resolveDispute);

module.exports = router;
