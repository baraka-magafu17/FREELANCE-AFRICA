// routes/review.routes.js
const express = require('express');
const router  = express.Router();
const { createReview, getUserReviews } = require('../controllers/review.controller');
const { authenticate } = require('../middleware/auth.middleware');

router.post('/',              authenticate, createReview);
router.get ('/user/:user_id', getUserReviews);

module.exports = router;
