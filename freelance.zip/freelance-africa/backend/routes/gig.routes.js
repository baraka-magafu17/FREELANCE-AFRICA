// routes/gig.routes.js
const express = require('express');
const router  = express.Router();
const {
  getGigs, getGigBySlug, createGig, updateGig, deleteGig, getCategories,
} = require('../controllers/gig.controller');
const { authenticate, authorize } = require('../middleware/auth.middleware');

router.get  ('/categories',   getCategories);
router.get  ('/',             getGigs);
router.get  ('/:slug',        getGigBySlug);
router.post ('/',             authenticate, authorize('freelancer'), createGig);
router.put  ('/:id',          authenticate, updateGig);
router.delete('/:id',         authenticate, deleteGig);

module.exports = router;
