// routes/message.routes.js
const express = require('express');
const router  = express.Router();
const { getMessages, sendMessage } = require('../controllers/message.controller');
const { authenticate } = require('../middleware/auth.middleware');

router.get ('/:order_id', authenticate, getMessages);
router.post('/:order_id', authenticate, sendMessage);

module.exports = router;

