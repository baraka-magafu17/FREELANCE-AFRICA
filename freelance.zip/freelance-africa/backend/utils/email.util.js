// utils/email.util.js
const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  host:   process.env.SMTP_HOST,
  port:   Number(process.env.SMTP_PORT) || 587,
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

exports.sendVerificationEmail = async (email, firstName, token) => {
  const verifyUrl = `${process.env.FRONTEND_URL}/verify-email/${token}`;
  await transporter.sendMail({
    from:    process.env.EMAIL_FROM,
    to:      email,
    subject: 'Verify your FreelanceAfrica account',
    html: `
      <div style="font-family:Arial,sans-serif;max-width:600px;margin:auto">
        <h2 style="color:#16a34a">Welcome to FreelanceAfrica, ${firstName}!</h2>
        <p>Click the button below to verify your email address and activate your account.</p>
        <a href="${verifyUrl}"
           style="display:inline-block;padding:12px 24px;background:#16a34a;color:#fff;border-radius:6px;text-decoration:none;font-weight:bold">
          Verify Email
        </a>
        <p style="color:#666;font-size:12px;margin-top:20px">
          This link expires in 24 hours. If you did not create an account, please ignore this email.
        </p>
      </div>
    `,
  });
};

exports.sendOrderNotification = async (email, subject, htmlBody) => {
  await transporter.sendMail({
    from:    process.env.EMAIL_FROM,
    to:      email,
    subject,
    html:    htmlBody,
  });
};
