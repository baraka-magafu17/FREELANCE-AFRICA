// controllers/gig.controller.js
const db   = require('../config/db');
const { v4: uuidv4 } = require('uuid');

// ── Helper: slugify ───────────────────────────────────
const slugify = (text) =>
  text.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')
  + '-' + uuidv4().split('-')[0];

// ── GET /api/gigs — Browse catalog ───────────────────
exports.getGigs = async (req, res) => {
  try {
    const {
      category, keyword, min_price, max_price,
      delivery_days, min_rating, page = 1, limit = 12,
    } = req.query;

    const offset = (page - 1) * limit;
    const params = [];
    let where = "g.status = 'active'";

    if (category) { where += ' AND c.slug = ?'; params.push(category); }
    if (keyword)  { where += ' AND MATCH(g.title, g.description, g.tags) AGAINST(? IN BOOLEAN MODE)'; params.push(`*${keyword}*`); }
    if (min_price){ where += ' AND p.price >= ?'; params.push(min_price); }
    if (max_price){ where += ' AND p.price <= ?'; params.push(max_price); }
    if (delivery_days){ where += ' AND p.delivery_days <= ?'; params.push(delivery_days); }
    if (min_rating){ where += ' AND g.avg_rating >= ?'; params.push(min_rating); }

    const sql = `
      SELECT g.gig_id, g.title, g.slug, g.thumbnail_url, g.avg_rating, g.total_orders, g.total_reviews,
             u.username, u.first_name, u.last_name, u.avatar_url,
             c.name AS category_name, c.slug AS category_slug,
             MIN(p.price) AS starting_price, MIN(p.currency) AS currency
      FROM gigs g
      JOIN users u ON g.freelancer_id = u.user_id
      JOIN categories c ON g.category_id = c.category_id
      LEFT JOIN gig_packages p ON g.gig_id = p.gig_id AND p.tier = 'basic'
      WHERE ${where}
      GROUP BY g.gig_id
      ORDER BY g.total_orders DESC, g.avg_rating DESC
      LIMIT ? OFFSET ?
    `;

    params.push(Number(limit), Number(offset));
    const [gigs] = await db.execute(sql, params);

    // Count for pagination
    const countSql = `
      SELECT COUNT(DISTINCT g.gig_id) AS total
      FROM gigs g
      JOIN users u ON g.freelancer_id = u.user_id
      JOIN categories c ON g.category_id = c.category_id
      LEFT JOIN gig_packages p ON g.gig_id = p.gig_id AND p.tier = 'basic'
      WHERE ${where}
    `;
    const [countRows] = await db.execute(countSql, params.slice(0, -2));
    const total = countRows[0].total;

    res.json({
      success: true,
      data: gigs,
      pagination: {
        total,
        page: Number(page),
        limit: Number(limit),
        pages: Math.ceil(total / limit),
      },
    });
  } catch (err) {
    console.error('getGigs error:', err);
    res.status(500).json({ success: false, message: 'Failed to fetch gigs' });
  }
};

// ── GET /api/gigs/:slug — Single gig detail ───────────
exports.getGigBySlug = async (req, res) => {
  try {
    const [gigs] = await db.execute(
      `SELECT g.*, u.username, u.first_name, u.last_name, u.avatar_url, u.country_id,
              c.name AS category_name, c.slug AS category_slug,
              fp.tagline, fp.avg_rating AS freelancer_rating, fp.total_orders AS freelancer_orders,
              fp.response_time_hrs, fp.languages
       FROM gigs g
       JOIN users u ON g.freelancer_id = u.user_id
       JOIN categories c ON g.category_id = c.category_id
       LEFT JOIN freelancer_profiles fp ON u.user_id = fp.user_id
       WHERE g.slug = ? AND g.status = 'active'`,
      [req.params.slug]
    );

    if (!gigs.length) return res.status(404).json({ success: false, message: 'Gig not found' });

    const gig = gigs[0];

    // Fetch packages
    const [packages] = await db.execute(
      'SELECT * FROM gig_packages WHERE gig_id = ? ORDER BY FIELD(tier,"basic","standard","premium")',
      [gig.gig_id]
    );

    // Fetch images
    const [images] = await db.execute(
      'SELECT image_url FROM gig_images WHERE gig_id = ? ORDER BY sort_order',
      [gig.gig_id]
    );

    // Fetch recent reviews
    const [reviews] = await db.execute(
      `SELECT r.rating, r.comment, r.created_at,
              u.username, u.first_name, u.last_name, u.avatar_url
       FROM reviews r JOIN users u ON r.reviewer_id = u.user_id
       WHERE r.gig_id = ? AND r.is_public = 1
       ORDER BY r.created_at DESC LIMIT 10`,
      [gig.gig_id]
    );

    res.json({ success: true, data: { ...gig, packages, images, reviews } });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch gig' });
  }
};

// ── POST /api/gigs — Create gig (freelancer only) ─────
exports.createGig = async (req, res) => {
  const conn = await db.getConnection();
  try {
    const { title, description, category_id, tags, packages } = req.body;
    const freelancer_id = req.user.user_id;

    // Max 20 gigs per freelancer
    const [count] = await conn.execute(
      "SELECT COUNT(*) AS total FROM gigs WHERE freelancer_id = ? AND status != 'deleted'",
      [freelancer_id]
    );
    if (count[0].total >= 20) {
      return res.status(400).json({ success: false, message: 'Maximum 20 active gigs allowed per account' });
    }

    const slug = slugify(title);
    await conn.beginTransaction();

    const [result] = await conn.execute(
      `INSERT INTO gigs (freelancer_id, category_id, title, slug, description, tags)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [freelancer_id, category_id, title, slug, description, tags || '']
    );

    const gigId = result.insertId;

    // Insert packages (at least basic is required)
    if (packages && packages.length) {
      for (const pkg of packages) {
        await conn.execute(
          `INSERT INTO gig_packages
             (gig_id, tier, title, description, price, currency, delivery_days, revisions)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
          [gigId, pkg.tier, pkg.title, pkg.description, pkg.price, pkg.currency || 'USD',
           pkg.delivery_days, pkg.revisions || 1]
        );
      }
    }

    await conn.commit();

    res.status(201).json({
      success: true,
      message: 'Gig created successfully',
      data: { gig_id: gigId, slug },
    });
  } catch (err) {
    await conn.rollback();
    console.error('createGig error:', err);
    res.status(500).json({ success: false, message: 'Failed to create gig' });
  } finally {
    conn.release();
  }
};

// ── PUT /api/gigs/:id — Update gig ───────────────────
exports.updateGig = async (req, res) => {
  try {
    const { title, description, category_id, tags, status } = req.body;
    const { id } = req.params;

    const [rows] = await db.execute(
      'SELECT freelancer_id FROM gigs WHERE gig_id = ?', [id]
    );
    if (!rows.length) return res.status(404).json({ success: false, message: 'Gig not found' });
    if (rows[0].freelancer_id !== req.user.user_id && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }

    await db.execute(
      `UPDATE gigs SET title=?, description=?, category_id=?, tags=?, status=?, updated_at=NOW()
       WHERE gig_id=?`,
      [title, description, category_id, tags, status, id]
    );

    res.json({ success: true, message: 'Gig updated successfully' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to update gig' });
  }
};

// ── DELETE /api/gigs/:id — Soft delete ───────────────
exports.deleteGig = async (req, res) => {
  try {
    const [rows] = await db.execute('SELECT freelancer_id FROM gigs WHERE gig_id = ?', [req.params.id]);
    if (!rows.length) return res.status(404).json({ success: false, message: 'Gig not found' });
    if (rows[0].freelancer_id !== req.user.user_id && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }
    await db.execute("UPDATE gigs SET status = 'deleted' WHERE gig_id = ?", [req.params.id]);
    res.json({ success: true, message: 'Gig deleted successfully' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to delete gig' });
  }
};

// ── GET /api/gigs/categories — All categories ─────────
exports.getCategories = async (req, res) => {
  try {
    const [cats] = await db.execute("SELECT * FROM categories WHERE is_active = 1 ORDER BY name");
    res.json({ success: true, data: cats });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch categories' });
  }
};
