// controllers/message.controller.js
const db = require('../config/db');

// GET /api/messages/:order_id — Load chat history
exports.getMessages = async (req, res) => {
  try {
    const { order_id } = req.params;
    const userId = req.user.user_id;

    // Verify user is party to this order
    const [orders] = await db.execute(
      'SELECT client_id, freelancer_id FROM orders WHERE order_id = ?',
      [order_id]
    );
    if (!orders.length) return res.status(404).json({ success: false, message: 'Order not found' });

    const order = orders[0];
    const isParty = order.client_id === userId || order.freelancer_id === userId || req.user.role === 'admin';
    if (!isParty) return res.status(403).json({ success: false, message: 'Access denied' });

    const [messages] = await db.execute(
      `SELECT m.message_id, m.body, m.attachment_url, m.is_read, m.sent_at,
              u.user_id AS sender_id, u.username, u.avatar_url, u.role
       FROM messages m
       JOIN users u ON m.sender_id = u.user_id
       WHERE m.order_id = ?
       ORDER BY m.sent_at ASC`,
      [order_id]
    );

    // Mark messages as read for this user
    await db.execute(
      'UPDATE messages SET is_read = 1 WHERE order_id = ? AND receiver_id = ? AND is_read = 0',
      [order_id, userId]
    );

    res.json({ success: true, data: messages });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to load messages' });
  }
};

// POST /api/messages/:order_id — Send a message
exports.sendMessage = async (req, res) => {
  try {
    const { order_id } = req.params;
    const { body, attachment_url } = req.body;
    const senderId = req.user.user_id;

    const [orders] = await db.execute(
      'SELECT client_id, freelancer_id, status FROM orders WHERE order_id = ?',
      [order_id]
    );
    if (!orders.length) return res.status(404).json({ success: false, message: 'Order not found' });

    const order = orders[0];
    const isParty = order.client_id === senderId || order.freelancer_id === senderId;
    if (!isParty) return res.status(403).json({ success: false, message: 'Access denied' });

    const receiverId = senderId === order.client_id ? order.freelancer_id : order.client_id;

    const [result] = await db.execute(
      'INSERT INTO messages (order_id, sender_id, receiver_id, body, attachment_url) VALUES (?, ?, ?, ?, ?)',
      [order_id, senderId, receiverId, body, attachment_url || null]
    );

    const newMessage = {
      message_id:     result.insertId,
      order_id:       Number(order_id),
      sender_id:      senderId,
      receiver_id:    receiverId,
      body,
      attachment_url: attachment_url || null,
      is_read:        0,
      sent_at:        new Date().toISOString(),
      username:       req.user.username,
    };

    // Broadcast via Socket.IO
    const io = req.app.get('io');
    if (io) io.to(`order_${order_id}`).emit('new_message', newMessage);

    res.status(201).json({ success: true, data: newMessage });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to send message' });
  }
};
