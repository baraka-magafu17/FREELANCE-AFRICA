// controllers/admin.controller.js
const db = require('../config/db');

// GET /api/admin/stats — Platform overview
exports.getDashboardStats = async (req, res) => {
  try {
    const [[users]]    = await db.execute('SELECT COUNT(*) AS total FROM users WHERE role != "admin"');
    const [[gigs]]     = await db.execute("SELECT COUNT(*) AS total FROM gigs WHERE status = 'active'");
    const [[orders]]   = await db.execute('SELECT COUNT(*) AS total FROM orders');
    const [[revenue]]  = await db.execute("SELECT COALESCE(SUM(amount),0) AS total FROM payments WHERE status = 'released'");
    const [[disputes]] = await db.execute("SELECT COUNT(*) AS total FROM disputes WHERE status = 'open'");
    const [[pending]]  = await db.execute("SELECT COUNT(*) AS total FROM orders WHERE status = 'pending'");

    // Orders by status
    const [ordersByStatus] = await db.execute(
      'SELECT status, COUNT(*) AS count FROM orders GROUP BY status'
    );

    // Recent signups (last 7 days)
    const [recentUsers] = await db.execute(
      "SELECT DATE(created_at) AS date, COUNT(*) AS count FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) GROUP BY DATE(created_at) ORDER BY date"
    );

    // Top freelancers
    const [topFreelancers] = await db.execute(
      `SELECT u.username, u.avatar_url, fp.avg_rating, fp.total_orders
       FROM freelancer_profiles fp JOIN users u ON fp.user_id = u.user_id
       ORDER BY fp.total_orders DESC LIMIT 5`
    );

    res.json({
      success: true,
      data: {
        totals: {
          users:    users.total,
          gigs:     gigs.total,
          orders:   orders.total,
          revenue:  revenue.total,
          disputes: disputes.total,
          pending_orders: pending.total,
        },
        orders_by_status: ordersByStatus,
        recent_signups:   recentUsers,
        top_freelancers:  topFreelancers,
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch stats' });
  }
};

// GET /api/admin/users — List all users
exports.getAllUsers = async (req, res) => {
  try {
    const { role, status, page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;
    const params = [];
    let where = '1=1';

    if (role)   { where += ' AND role = ?'; params.push(role); }
    if (status !== undefined) { where += ' AND is_active = ?'; params.push(status === 'active' ? 1 : 0); }

    const [users] = await db.execute(
      `SELECT user_id, first_name, last_name, username, email, role,
              is_active, is_email_verified, created_at, last_login
       FROM users WHERE ${where}
       ORDER BY created_at DESC LIMIT ? OFFSET ?`,
      [...params, Number(limit), Number(offset)]
    );

    const [[{ total }]] = await db.execute(
      `SELECT COUNT(*) AS total FROM users WHERE ${where}`, params
    );

    res.json({
      success: true,
      data: users,
      pagination: { total, page: Number(page), limit: Number(limit), pages: Math.ceil(total / limit) },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch users' });
  }
};

// PUT /api/admin/users/:id/toggle — Activate/deactivate user
exports.toggleUserStatus = async (req, res) => {
  try {
    const [rows] = await db.execute('SELECT is_active FROM users WHERE user_id = ?', [req.params.id]);
    if (!rows.length) return res.status(404).json({ success: false, message: 'User not found' });

    const newStatus = rows[0].is_active ? 0 : 1;
    await db.execute('UPDATE users SET is_active = ? WHERE user_id = ?', [newStatus, req.params.id]);

    await db.execute(
      `INSERT INTO audit_log (user_id, action, entity, entity_id, details) VALUES (?, ?, 'user', ?, ?)`,
      [req.user.user_id, newStatus ? 'user_activated' : 'user_deactivated', req.params.id,
       JSON.stringify({ toggled_by: req.user.user_id })]
    );

    res.json({ success: true, message: `User ${newStatus ? 'activated' : 'deactivated'} successfully` });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to update user status' });
  }
};

// GET /api/admin/disputes — List disputes
exports.getDisputes = async (req, res) => {
  try {
    const { status, page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;
    const params = [];
    let where = '1=1';
    if (status) { where += ' AND d.status = ?'; params.push(status); }

    const [disputes] = await db.execute(
      `SELECT d.*, o.order_ref, o.amount, o.currency,
              u_r.username AS raised_by_username,
              u_c.username AS client_username,
              u_f.username AS freelancer_username
       FROM disputes d
       JOIN orders o ON d.order_id = o.order_id
       JOIN users u_r ON d.raised_by = u_r.user_id
       JOIN users u_c ON o.client_id = u_c.user_id
       JOIN users u_f ON o.freelancer_id = u_f.user_id
       WHERE ${where}
       ORDER BY d.created_at DESC LIMIT ? OFFSET ?`,
      [...params, Number(limit), Number(offset)]
    );

    res.json({ success: true, data: disputes });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch disputes' });
  }
};

// PUT /api/admin/disputes/:id/resolve — Resolve dispute
exports.resolveDispute = async (req, res) => {
  const conn = await db.getConnection();
  try {
    const { resolution, admin_notes } = req.body; // 'resolved_client' or 'resolved_freelancer'
    const { id } = req.params;

    const [disputes] = await conn.execute(
      "SELECT * FROM disputes WHERE dispute_id = ? AND status = 'open'",
      [id]
    );
    if (!disputes.length) return res.status(404).json({ success: false, message: 'Dispute not found' });

    await conn.beginTransaction();

    await conn.execute(
      'UPDATE disputes SET status = ?, admin_notes = ?, resolved_by = ?, resolved_at = NOW() WHERE dispute_id = ?',
      [resolution, admin_notes, req.user.user_id, id]
    );

    // Update order accordingly
    const orderStatus = resolution === 'resolved_client' ? 'cancelled' : 'completed';
    await conn.execute(
      'UPDATE orders SET status = ?, updated_at = NOW() WHERE order_id = ?',
      [orderStatus, disputes[0].order_id]
    );

    // If resolved in favour of freelancer — release escrow
    if (resolution === 'resolved_freelancer') {
      const [orders] = await conn.execute('SELECT * FROM orders WHERE order_id = ?', [disputes[0].order_id]);
      await conn.execute(
        "UPDATE payments SET status = 'released', escrow_released_at = NOW() WHERE order_id = ? AND status = 'held'",
        [disputes[0].order_id]
      );
      await conn.execute(
        'UPDATE wallets SET balance = balance + ?, total_earned = total_earned + ? WHERE user_id = ?',
        [orders[0].amount, orders[0].amount, orders[0].freelancer_id]
      );
    }
    // If resolved in favour of client — refund
    if (resolution === 'resolved_client') {
      await conn.execute(
        "UPDATE payments SET status = 'refunded' WHERE order_id = ? AND status = 'held'",
        [disputes[0].order_id]
      );
    }

    await conn.commit();
    res.json({ success: true, message: 'Dispute resolved successfully' });
  } catch (err) {
    await conn.rollback();
    res.status(500).json({ success: false, message: 'Failed to resolve dispute' });
  } finally {
    conn.release();
  }
};
