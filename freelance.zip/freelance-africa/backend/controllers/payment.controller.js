// controllers/payment.controller.js
const db   = require('../config/db');
const https = require('https');

// ════════════════════════════════════════════════════
//  M-PESA DARAJA (Safaricom Sandbox)
// ════════════════════════════════════════════════════

// Helper: get M-Pesa OAuth token
const getMpesaToken = () => {
  return new Promise((resolve, reject) => {
    const auth = Buffer.from(
      `${process.env.MPESA_CONSUMER_KEY}:${process.env.MPESA_CONSUMER_SECRET}`
    ).toString('base64');

    const options = {
      hostname: 'sandbox.safaricom.co.ke',
      path: '/oauth/v1/generate?grant_type=client_credentials',
      method: 'GET',
      headers: { Authorization: `Basic ${auth}` },
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try { resolve(JSON.parse(data).access_token); }
        catch (e) { reject(new Error('Failed to parse M-Pesa token')); }
      });
    });
    req.on('error', reject);
    req.end();
  });
};

// POST /api/payments/mpesa/stk-push
exports.mpesaStkPush = async (req, res) => {
  try {
    const { order_id, phone_number } = req.body;

    const [orders] = await db.execute(
      'SELECT * FROM orders WHERE order_id = ? AND client_id = ?',
      [order_id, req.user.user_id]
    );
    if (!orders.length) return res.status(404).json({ success: false, message: 'Order not found' });

    const order  = orders[0];
    const token  = await getMpesaToken();
    const timestamp = new Date().toISOString().replace(/[-:T.Z]/g, '').slice(0, 14);
    const password  = Buffer.from(
      process.env.MPESA_SHORTCODE + process.env.MPESA_PASSKEY + timestamp
    ).toString('base64');

    // Convert amount to KES integer for M-Pesa (minimum 1)
    const amount = Math.max(1, Math.round(Number(order.amount)));

    const payload = JSON.stringify({
      BusinessShortCode: process.env.MPESA_SHORTCODE,
      Password:          password,
      Timestamp:         timestamp,
      TransactionType:   'CustomerPayBillOnline',
      Amount:            amount,
      PartyA:            phone_number,
      PartyB:            process.env.MPESA_SHORTCODE,
      PhoneNumber:       phone_number,
      CallBackURL:       process.env.MPESA_CALLBACK_URL,
      AccountReference:  order.order_ref,
      TransactionDesc:   `Payment for ${order.order_ref}`,
    });

    const stkRes = await new Promise((resolve, reject) => {
      const options = {
        hostname: 'sandbox.safaricom.co.ke',
        path: '/mpesa/stkpush/v1/processrequest',
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(payload),
        },
      };
      const r = https.request(options, (response) => {
        let data = '';
        response.on('data', (c) => { data += c; });
        response.on('end', () => resolve(JSON.parse(data)));
      });
      r.on('error', reject);
      r.write(payload);
      r.end();
    });

    if (stkRes.ResponseCode !== '0') {
      return res.status(400).json({ success: false, message: stkRes.ResponseDescription || 'STK Push failed' });
    }

    // Record pending payment
    await db.execute(
      `INSERT INTO payments (order_id, payer_id, payee_id, gateway, gateway_ref, amount, currency, status, phone_number, metadata)
       VALUES (?, ?, ?, 'mpesa', ?, ?, ?, 'pending', ?, ?)`,
      [order_id, req.user.user_id, order.freelancer_id,
       stkRes.CheckoutRequestID, order.amount, order.currency,
       phone_number, JSON.stringify(stkRes)]
    );

    res.json({
      success: true,
      message: 'STK Push sent. Enter your M-Pesa PIN on your phone.',
      data: { checkout_request_id: stkRes.CheckoutRequestID },
    });
  } catch (err) {
    console.error('M-Pesa STK error:', err);
    res.status(500).json({ success: false, message: 'M-Pesa payment initiation failed' });
  }
};

// POST /api/payments/mpesa/callback  (called by Safaricom)
exports.mpesaCallback = async (req, res) => {
  const conn = await db.getConnection();
  try {
    const body = req.body?.Body?.stkCallback;
    if (!body) return res.json({ ResultCode: 0, ResultDesc: 'Accepted' });

    const checkoutId = body.CheckoutRequestID;
    const resultCode = body.ResultCode;

    const [payments] = await conn.execute(
      'SELECT * FROM payments WHERE gateway_ref = ? AND gateway = "mpesa"',
      [checkoutId]
    );
    if (!payments.length) return res.json({ ResultCode: 0, ResultDesc: 'Accepted' });

    const payment = payments[0];
    await conn.beginTransaction();

    if (resultCode === 0) {
      // Payment successful — put in escrow
      await conn.execute(
        "UPDATE payments SET status = 'held', escrow_held_at = NOW(), metadata = ? WHERE gateway_ref = ?",
        [JSON.stringify(body), checkoutId]
      );
      await conn.execute(
        "UPDATE orders SET status = 'active', is_paid = 1, updated_at = NOW() WHERE order_id = ?",
        [payment.order_id]
      );
    } else {
      await conn.execute(
        "UPDATE payments SET status = 'failed', metadata = ? WHERE gateway_ref = ?",
        [JSON.stringify(body), checkoutId]
      );
    }

    await conn.commit();
    res.json({ ResultCode: 0, ResultDesc: 'Accepted' });
  } catch (err) {
    await conn.rollback();
    console.error('M-Pesa callback error:', err);
    res.json({ ResultCode: 0, ResultDesc: 'Accepted' });
  } finally {
    conn.release();
  }
};

// ════════════════════════════════════════════════════
//  FLUTTERWAVE (Sandbox)
// ════════════════════════════════════════════════════

// POST /api/payments/flutterwave/initiate
exports.flutterwaveInitiate = async (req, res) => {
  try {
    const { order_id } = req.body;
    const user = req.user;

    const [orders] = await db.execute(
      'SELECT o.*, u.email, u.first_name, u.last_name FROM orders o JOIN users u ON o.client_id = u.user_id WHERE o.order_id = ? AND o.client_id = ?',
      [order_id, user.user_id]
    );
    if (!orders.length) return res.status(404).json({ success: false, message: 'Order not found' });

    const order = orders[0];
    const tx_ref = `FA-FLW-${order.order_ref}-${Date.now()}`;

    const payload = JSON.stringify({
      tx_ref,
      amount:       order.amount,
      currency:     order.currency,
      redirect_url: `${process.env.FRONTEND_URL}/orders/${order_id}/payment-callback`,
      customer: {
        email:      order.email,
        name:       `${order.first_name} ${order.last_name}`,
      },
      customizations: {
        title:       'FreelanceAfrica',
        description: `Payment for order ${order.order_ref}`,
        logo:        `${process.env.FRONTEND_URL}/logo.png`,
      },
      meta: { order_id: order_id, order_ref: order.order_ref },
    });

    const flwRes = await new Promise((resolve, reject) => {
      const options = {
        hostname: 'api.flutterwave.com',
        path:     '/v3/payments',
        method:   'POST',
        headers: {
          Authorization:  `Bearer ${process.env.FLW_SECRET_KEY}`,
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(payload),
        },
      };
      const r = https.request(options, (response) => {
        let data = '';
        response.on('data', (c) => { data += c; });
        response.on('end', () => resolve(JSON.parse(data)));
      });
      r.on('error', reject);
      r.write(payload);
      r.end();
    });

    if (flwRes.status !== 'success') {
      return res.status(400).json({ success: false, message: 'Payment initiation failed' });
    }

    // Record pending payment
    await db.execute(
      `INSERT INTO payments (order_id, payer_id, payee_id, gateway, gateway_ref, amount, currency, status, metadata)
       VALUES (?, ?, ?, 'flutterwave', ?, ?, ?, 'pending', ?)`,
      [order_id, user.user_id, order.freelancer_id,
       tx_ref, order.amount, order.currency, JSON.stringify(flwRes)]
    );

    res.json({
      success: true,
      message: 'Flutterwave payment initiated',
      data: { payment_link: flwRes.data.link },
    });
  } catch (err) {
    console.error('Flutterwave initiate error:', err);
    res.status(500).json({ success: false, message: 'Payment initiation failed' });
  }
};

// POST /api/payments/flutterwave/webhook (called by Flutterwave)
exports.flutterwaveWebhook = async (req, res) => {
  const conn = await db.getConnection();
  try {
    // Verify webhook signature
    const hash = req.headers['verif-hash'];
    if (hash !== process.env.FLW_WEBHOOK_SECRET) {
      return res.status(401).send('Unauthorized');
    }

    const { event, data } = req.body;
    if (event !== 'charge.completed' || data.status !== 'successful') {
      return res.sendStatus(200);
    }

    const [payments] = await conn.execute(
      'SELECT * FROM payments WHERE gateway_ref = ? AND gateway = "flutterwave"',
      [data.tx_ref]
    );
    if (!payments.length) return res.sendStatus(200);

    await conn.beginTransaction();

    await conn.execute(
      "UPDATE payments SET status = 'held', escrow_held_at = NOW(), metadata = ? WHERE gateway_ref = ?",
      [JSON.stringify(data), data.tx_ref]
    );
    await conn.execute(
      "UPDATE orders SET status = 'active', is_paid = 1, updated_at = NOW() WHERE order_id = ?",
      [payments[0].order_id]
    );

    await conn.commit();
    res.sendStatus(200);
  } catch (err) {
    await conn.rollback();
    console.error('FLW webhook error:', err);
    res.sendStatus(200);
  } finally {
    conn.release();
  }
};

// GET /api/payments/order/:order_id — Payment status
exports.getPaymentStatus = async (req, res) => {
  try {
    const [payments] = await db.execute(
      'SELECT payment_id, gateway, status, amount, currency, escrow_held_at, escrow_released_at, created_at FROM payments WHERE order_id = ?',
      [req.params.order_id]
    );
    res.json({ success: true, data: payments });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch payment status' });
  }
};
