// controllers/order.controller.js
const db = require('../config/db');

// ── Helper: generate order reference ─────────────────
const generateOrderRef = () => {
  const year = new Date().getFullYear();
  const rand = Math.floor(Math.random() * 90000) + 10000;
  return `FA-${year}${rand}`;
};

// ── POST /api/orders — Place order ───────────────────
exports.createOrder = async (req, res) => {
  const conn = await db.getConnection();
  try {
    const { gig_id, package_id, requirements } = req.body;
    const client_id = req.user.user_id;

    // Validate gig & package
    const [gigs] = await conn.execute(
      "SELECT g.gig_id, g.freelancer_id FROM gigs g WHERE g.gig_id = ? AND g.status = 'active'",
      [gig_id]
    );
    if (!gigs.length) return res.status(404).json({ success: false, message: 'Gig not found or inactive' });

    const { freelancer_id } = gigs[0];

    if (client_id === freelancer_id) {
      return res.status(400).json({ success: false, message: 'You cannot order your own gig' });
    }

    const [pkgs] = await conn.execute(
      'SELECT * FROM gig_packages WHERE package_id = ? AND gig_id = ?',
      [package_id, gig_id]
    );
    if (!pkgs.length) return res.status(404).json({ success: false, message: 'Package not found' });

    const pkg = pkgs[0];
    const due_date = new Date();
    due_date.setDate(due_date.getDate() + pkg.delivery_days);

    await conn.beginTransaction();

    const order_ref = generateOrderRef();
    const [result] = await conn.execute(
      `INSERT INTO orders
         (order_ref, client_id, freelancer_id, gig_id, package_id, requirements,
          delivery_days, due_date, amount, currency)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [order_ref, client_id, freelancer_id, gig_id, package_id, requirements,
       pkg.delivery_days, due_date.toISOString().split('T')[0],
       pkg.price, pkg.currency]
    );

    const order_id = result.insertId;

    // Notify freelancer
    await conn.execute(
      `INSERT INTO notifications (user_id, type, title, body, link)
       VALUES (?, 'new_order', 'New Order Received', ?, ?)`,
      [freelancer_id, `You have a new order: ${order_ref}`, `/orders/${order_id}`]
    );

    await conn.commit();

    // Emit socket notification
    const io = req.app.get('io');
    if (io) io.to(`user_${freelancer_id}`).emit('new_notification', { type: 'new_order', order_id });

    res.status(201).json({
      success: true,
      message: 'Order placed successfully. Please complete payment to activate.',
      data: { order_id, order_ref, amount: pkg.price, currency: pkg.currency },
    });
  } catch (err) {
    await conn.rollback();
    console.error('createOrder error:', err);
    res.status(500).json({ success: false, message: 'Failed to create order' });
  } finally {
    conn.release();
  }
};

// ── GET /api/orders — My orders (client or freelancer) ─
exports.getMyOrders = async (req, res) => {
  try {
    const { status, page = 1, limit = 10 } = req.query;
    const userId = req.user.user_id;
    const role   = req.user.role;
    const offset = (page - 1) * limit;

    const roleFilter = role === 'freelancer' ? 'o.freelancer_id = ?' : 'o.client_id = ?';
    const params = [userId];

    let where = roleFilter;
    if (status) { where += ' AND o.status = ?'; params.push(status); }

    const [orders] = await db.execute(
      `SELECT o.order_id, o.order_ref, o.status, o.amount, o.currency,
              o.delivery_days, o.due_date, o.created_at, o.is_paid,
              g.title AS gig_title, g.thumbnail_url,
              u_c.username AS client_username, u_c.avatar_url AS client_avatar,
              u_f.username AS freelancer_username, u_f.avatar_url AS freelancer_avatar
       FROM orders o
       JOIN gigs g ON o.gig_id = g.gig_id
       JOIN users u_c ON o.client_id = u_c.user_id
       JOIN users u_f ON o.freelancer_id = u_f.user_id
       WHERE ${where}
       ORDER BY o.created_at DESC
       LIMIT ? OFFSET ?`,
      [...params, Number(limit), Number(offset)]
    );

    const [[{ total }]] = await db.execute(
      `SELECT COUNT(*) AS total FROM orders o WHERE ${where}`,
      params
    );

    res.json({
      success: true,
      data: orders,
      pagination: { total, page: Number(page), limit: Number(limit), pages: Math.ceil(total / limit) },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch orders' });
  }
};

// ── GET /api/orders/:id — Single order detail ─────────
exports.getOrderById = async (req, res) => {
  try {
    const [orders] = await db.execute(
      `SELECT o.*, g.title AS gig_title, g.slug AS gig_slug, g.thumbnail_url,
              p.tier, p.title AS package_title, p.description AS package_description,
              u_c.username AS client_username, u_c.first_name AS client_first, u_c.avatar_url AS client_avatar,
              u_f.username AS freelancer_username, u_f.first_name AS freelancer_first, u_f.avatar_url AS freelancer_avatar
       FROM orders o
       JOIN gigs g ON o.gig_id = g.gig_id
       JOIN gig_packages p ON o.package_id = p.package_id
       JOIN users u_c ON o.client_id = u_c.user_id
       JOIN users u_f ON o.freelancer_id = u_f.user_id
       WHERE o.order_id = ?`,
      [req.params.id]
    );

    if (!orders.length) return res.status(404).json({ success: false, message: 'Order not found' });

    const order = orders[0];
    const userId = req.user.user_id;
    const isParty = order.client_id === userId || order.freelancer_id === userId || req.user.role === 'admin';
    if (!isParty) return res.status(403).json({ success: false, message: 'Access denied' });

    // Fetch deliveries
    const [deliveries] = await db.execute(
      'SELECT * FROM order_deliveries WHERE order_id = ? ORDER BY delivered_at DESC',
      [order.order_id]
    );

    res.json({ success: true, data: { ...order, deliveries } });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch order' });
  }
};

// ── PUT /api/orders/:id/deliver — Freelancer delivers ─
exports.deliverOrder = async (req, res) => {
  const conn = await db.getConnection();
  try {
    const { message, file_urls } = req.body;
    const { id } = req.params;

    const [orders] = await conn.execute(
      "SELECT * FROM orders WHERE order_id = ? AND freelancer_id = ? AND status = 'active'",
      [id, req.user.user_id]
    );
    if (!orders.length) return res.status(404).json({ success: false, message: 'Order not found or not active' });

    await conn.beginTransaction();

    await conn.execute(
      'INSERT INTO order_deliveries (order_id, message, file_urls) VALUES (?, ?, ?)',
      [id, message, JSON.stringify(file_urls || [])]
    );

    await conn.execute(
      "UPDATE orders SET status = 'delivered', updated_at = NOW() WHERE order_id = ?",
      [id]
    );

    await conn.execute(
      `INSERT INTO notifications (user_id, type, title, body, link)
       VALUES (?, 'order_delivered', 'Order Delivered', ?, ?)`,
      [orders[0].client_id, `Your order ${orders[0].order_ref} has been delivered. Please review.`, `/orders/${id}`]
    );

    await conn.commit();

    const io = req.app.get('io');
    if (io) io.to(`user_${orders[0].client_id}`).emit('order_delivered', { order_id: id });

    res.json({ success: true, message: 'Order delivered successfully' });
  } catch (err) {
    await conn.rollback();
    res.status(500).json({ success: false, message: 'Failed to deliver order' });
  } finally {
    conn.release();
  }
};

// ── PUT /api/orders/:id/complete — Client accepts ─────
exports.completeOrder = async (req, res) => {
  const conn = await db.getConnection();
  try {
    const { id } = req.params;

    const [orders] = await conn.execute(
      "SELECT * FROM orders WHERE order_id = ? AND client_id = ? AND status IN ('delivered','revision_requested')",
      [id, req.user.user_id]
    );
    if (!orders.length) return res.status(404).json({ success: false, message: 'Order not found or cannot be completed' });

    await conn.beginTransaction();

    await conn.execute(
      "UPDATE orders SET status = 'completed', completed_at = NOW(), updated_at = NOW() WHERE order_id = ?",
      [id]
    );

    // Release escrow payment
    await conn.execute(
      "UPDATE payments SET status = 'released', escrow_released_at = NOW() WHERE order_id = ? AND status = 'held'",
      [id]
    );

    // Credit freelancer wallet
    await conn.execute(
      'UPDATE wallets SET balance = balance + ?, total_earned = total_earned + ? WHERE user_id = ?',
      [orders[0].amount, orders[0].amount, orders[0].freelancer_id]
    );

    // Update gig stats
    await conn.execute(
      'UPDATE gigs SET total_orders = total_orders + 1 WHERE gig_id = ?',
      [orders[0].gig_id]
    );

    // Notify freelancer
    await conn.execute(
      `INSERT INTO notifications (user_id, type, title, body, link) VALUES (?, 'order_completed', 'Order Completed & Payment Released', ?, ?)`,
      [orders[0].freelancer_id, `Order ${orders[0].order_ref} completed. Payment released to your wallet.`, `/orders/${id}`]
    );

    await conn.commit();

    const io = req.app.get('io');
    if (io) io.to(`user_${orders[0].freelancer_id}`).emit('order_completed', { order_id: id });

    res.json({ success: true, message: 'Order completed. Payment released to freelancer.' });
  } catch (err) {
    await conn.rollback();
    res.status(500).json({ success: false, message: 'Failed to complete order' });
  } finally {
    conn.release();
  }
};

// ── PUT /api/orders/:id/revision — Request revision ──
exports.requestRevision = async (req, res) => {
  try {
    const { reason } = req.body;
    const { id } = req.params;

    const [orders] = await db.execute(
      "SELECT * FROM orders WHERE order_id = ? AND client_id = ? AND status = 'delivered'",
      [id, req.user.user_id]
    );
    if (!orders.length) return res.status(404).json({ success: false, message: 'Order not found or revision not applicable' });

    await db.execute(
      "UPDATE orders SET status = 'revision_requested', updated_at = NOW() WHERE order_id = ?",
      [id]
    );

    const io = req.app.get('io');
    if (io) io.to(`order_${id}`).emit('revision_requested', { order_id: id, reason });

    res.json({ success: true, message: 'Revision requested' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to request revision' });
  }
};

// ── PUT /api/orders/:id/cancel — Cancel order ────────
exports.cancelOrder = async (req, res) => {
  const conn = await db.getConnection();
  try {
    const { reason } = req.body;
    const { id } = req.params;
    const userId = req.user.user_id;

    const [orders] = await conn.execute(
      "SELECT * FROM orders WHERE order_id = ? AND (client_id = ? OR freelancer_id = ?) AND status IN ('pending','active')",
      [id, userId, userId]
    );
    if (!orders.length) return res.status(404).json({ success: false, message: 'Order cannot be cancelled' });

    await conn.beginTransaction();

    await conn.execute(
      "UPDATE orders SET status = 'cancelled', cancel_reason = ?, cancelled_at = NOW() WHERE order_id = ?",
      [reason, id]
    );

    // Refund if payment was held
    await conn.execute(
      "UPDATE payments SET status = 'refunded' WHERE order_id = ? AND status = 'held'",
      [id]
    );

    await conn.commit();
    res.json({ success: true, message: 'Order cancelled successfully' });
  } catch (err) {
    await conn.rollback();
    res.status(500).json({ success: false, message: 'Failed to cancel order' });
  } finally {
    conn.release();
  }
};
