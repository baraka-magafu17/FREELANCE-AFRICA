// controllers/review.controller.js
const db = require('../config/db');

// POST /api/reviews — Submit review after order completion
exports.createReview = async (req, res) => {
  const conn = await db.getConnection();
  try {
    const { order_id, rating, comment } = req.body;
    const reviewer_id = req.user.user_id;

    // Order must be completed
    const [orders] = await conn.execute(
      "SELECT * FROM orders WHERE order_id = ? AND status = 'completed'",
      [order_id]
    );
    if (!orders.length) return res.status(404).json({ success: false, message: 'Order not found or not completed' });

    const order = orders[0];
    const isParty = order.client_id === reviewer_id || order.freelancer_id === reviewer_id;
    if (!isParty) return res.status(403).json({ success: false, message: 'Only order parties can review' });

    // Determine reviewee
    const reviewee_id = reviewer_id === order.client_id ? order.freelancer_id : order.client_id;

    // One review per order per user
    const [existing] = await conn.execute(
      'SELECT review_id FROM reviews WHERE order_id = ? AND reviewer_id = ?',
      [order_id, reviewer_id]
    );
    if (existing.length) return res.status(409).json({ success: false, message: 'You already reviewed this order' });

    await conn.beginTransaction();

    await conn.execute(
      'INSERT INTO reviews (order_id, reviewer_id, reviewee_id, gig_id, rating, comment) VALUES (?, ?, ?, ?, ?, ?)',
      [order_id, reviewer_id, reviewee_id, order.gig_id, rating, comment]
    );

    // Update gig average rating
    const [[stats]] = await conn.execute(
      'SELECT AVG(rating) AS avg_rating, COUNT(*) AS total FROM reviews WHERE gig_id = ? AND is_public = 1',
      [order.gig_id]
    );
    await conn.execute(
      'UPDATE gigs SET avg_rating = ?, total_reviews = ? WHERE gig_id = ?',
      [parseFloat(stats.avg_rating).toFixed(2), stats.total, order.gig_id]
    );

    // Update freelancer profile average rating
    if (reviewee_id === order.freelancer_id) {
      const [[fpStats]] = await conn.execute(
        `SELECT AVG(r.rating) AS avg_rating, COUNT(*) AS total
         FROM reviews r
         JOIN orders o ON r.order_id = o.order_id
         WHERE o.freelancer_id = ? AND r.is_public = 1`,
        [order.freelancer_id]
      );
      await conn.execute(
        'UPDATE freelancer_profiles SET avg_rating = ?, total_reviews = ? WHERE user_id = ?',
        [parseFloat(fpStats.avg_rating).toFixed(2), fpStats.total, order.freelancer_id]
      );
    }

    await conn.commit();
    res.status(201).json({ success: true, message: 'Review submitted successfully' });
  } catch (err) {
    await conn.rollback();
    res.status(500).json({ success: false, message: 'Failed to submit review' });
  } finally {
    conn.release();
  }
};

// GET /api/reviews/user/:user_id — Freelancer's public reviews
exports.getUserReviews = async (req, res) => {
  try {
    const [reviews] = await db.execute(
      `SELECT r.rating, r.comment, r.created_at,
              u.username, u.first_name, u.avatar_url,
              g.title AS gig_title, g.slug AS gig_slug
       FROM reviews r
       JOIN users u ON r.reviewer_id = u.user_id
       JOIN gigs g ON r.gig_id = g.gig_id
       WHERE r.reviewee_id = ? AND r.is_public = 1
       ORDER BY r.created_at DESC`,
      [req.params.user_id]
    );
    res.json({ success: true, data: reviews });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch reviews' });
  }
};
