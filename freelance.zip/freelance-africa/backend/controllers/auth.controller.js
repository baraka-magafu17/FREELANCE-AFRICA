// controllers/auth.controller.js
const bcrypt = require('bcryptjs');
const jwt    = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const db     = require('../config/db');
const { sendVerificationEmail } = require('../utils/email.util');

// ── Helper: generate tokens ────────────────────────────
const generateTokens = (userId, role) => {
  const accessToken = jwt.sign(
    { userId, role },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '15m' }
  );
  const refreshToken = jwt.sign(
    { userId, role },
    process.env.JWT_REFRESH_SECRET,
    { expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d' }
  );
  return { accessToken, refreshToken };
};

// ── REGISTER ──────────────────────────────────────────
exports.register = async (req, res) => {
  const conn = await db.getConnection();
  try {
    const { first_name, last_name, username, email, password, role, country_id } = req.body;

    // Check email/username uniqueness
    const [existing] = await conn.execute(
      'SELECT user_id FROM users WHERE email = ? OR username = ?',
      [email, username]
    );
    if (existing.length) {
      return res.status(409).json({ success: false, message: 'Email or username already taken' });
    }

    const password_hash   = await bcrypt.hash(password, 12);
    const email_verify_token = uuidv4();

    await conn.beginTransaction();

    // Insert user
    const [result] = await conn.execute(
      `INSERT INTO users
         (first_name, last_name, username, email, password_hash, role, country_id, email_verify_token)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [first_name, last_name, username, email, password_hash, role || 'client', country_id || null, email_verify_token]
    );

    const userId = result.insertId;

    // If registering as freelancer, create profile + wallet
    if (role === 'freelancer') {
      await conn.execute(
        'INSERT INTO freelancer_profiles (user_id) VALUES (?)',
        [userId]
      );
    }

    // Create wallet for all users
    await conn.execute(
      'INSERT INTO wallets (user_id, currency) VALUES (?, "USD")',
      [userId]
    );

    await conn.commit();

    // Send verification email (non-blocking)
    sendVerificationEmail(email, first_name, email_verify_token).catch(console.error);

    res.status(201).json({
      success: true,
      message: 'Registration successful. Please check your email to verify your account.',
    });
  } catch (err) {
    await conn.rollback();
    console.error('Register error:', err);
    res.status(500).json({ success: false, message: 'Registration failed. Please try again.' });
  } finally {
    conn.release();
  }
};

// ── VERIFY EMAIL ──────────────────────────────────────
exports.verifyEmail = async (req, res) => {
  try {
    const { token } = req.params;
    const [rows] = await db.execute(
      'SELECT user_id FROM users WHERE email_verify_token = ? AND is_email_verified = 0',
      [token]
    );
    if (!rows.length) {
      return res.status(400).json({ success: false, message: 'Invalid or expired verification link' });
    }
    await db.execute(
      'UPDATE users SET is_email_verified = 1, email_verify_token = NULL WHERE user_id = ?',
      [rows[0].user_id]
    );
    res.json({ success: true, message: 'Email verified successfully. You can now log in.' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Verification failed' });
  }
};

// ── LOGIN ─────────────────────────────────────────────
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    const [rows] = await db.execute(
      `SELECT user_id, email, password_hash, role, first_name, last_name,
              username, avatar_url, is_email_verified, is_active
       FROM users WHERE email = ?`,
      [email]
    );

    if (!rows.length) {
      return res.status(401).json({ success: false, message: 'Invalid email or password' });
    }

    const user = rows[0];

    if (!user.is_active) {
      return res.status(403).json({ success: false, message: 'Account has been deactivated' });
    }
    if (!user.is_email_verified) {
      return res.status(403).json({ success: false, message: 'Please verify your email before logging in' });
    }

    const isMatch = await bcrypt.compare(password, user.password_hash);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Invalid email or password' });
    }

    const { accessToken, refreshToken } = generateTokens(user.user_id, user.role);

    // Store refresh token hash
    const tokenHash = require('crypto')
      .createHash('sha256')
      .update(refreshToken)
      .digest('hex');

    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    await db.execute(
      'INSERT INTO refresh_tokens (user_id, token_hash, expires_at) VALUES (?, ?, ?)',
      [user.user_id, tokenHash, expiresAt]
    );

    // Update last login
    await db.execute('UPDATE users SET last_login = NOW() WHERE user_id = ?', [user.user_id]);

    res.json({
      success: true,
      message: 'Login successful',
      data: {
        accessToken,
        refreshToken,
        user: {
          user_id:    user.user_id,
          first_name: user.first_name,
          last_name:  user.last_name,
          username:   user.username,
          email:      user.email,
          role:       user.role,
          avatar_url: user.avatar_url,
        },
      },
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ success: false, message: 'Login failed. Please try again.' });
  }
};

// ── REFRESH TOKEN ─────────────────────────────────────
exports.refreshToken = async (req, res) => {
  try {
    const { refreshToken } = req.body;
    if (!refreshToken) {
      return res.status(400).json({ success: false, message: 'Refresh token required' });
    }

    const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);

    const tokenHash = require('crypto')
      .createHash('sha256')
      .update(refreshToken)
      .digest('hex');

    const [rows] = await db.execute(
      'SELECT token_id FROM refresh_tokens WHERE token_hash = ? AND user_id = ? AND revoked = 0 AND expires_at > NOW()',
      [tokenHash, decoded.userId]
    );

    if (!rows.length) {
      return res.status(401).json({ success: false, message: 'Invalid or expired refresh token' });
    }

    // Rotate: revoke old, issue new
    await db.execute('UPDATE refresh_tokens SET revoked = 1 WHERE token_hash = ?', [tokenHash]);

    const { accessToken, refreshToken: newRefresh } = generateTokens(decoded.userId, decoded.role);
    const newHash = require('crypto').createHash('sha256').update(newRefresh).digest('hex');
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

    await db.execute(
      'INSERT INTO refresh_tokens (user_id, token_hash, expires_at) VALUES (?, ?, ?)',
      [decoded.userId, newHash, expiresAt]
    );

    res.json({ success: true, data: { accessToken, refreshToken: newRefresh } });
  } catch (err) {
    res.status(401).json({ success: false, message: 'Invalid refresh token' });
  }
};

// ── LOGOUT ────────────────────────────────────────────
exports.logout = async (req, res) => {
  try {
    const { refreshToken } = req.body;
    if (refreshToken) {
      const tokenHash = require('crypto')
        .createHash('sha256')
        .update(refreshToken)
        .digest('hex');
      await db.execute('UPDATE refresh_tokens SET revoked = 1 WHERE token_hash = ?', [tokenHash]);
    }
    res.json({ success: true, message: 'Logged out successfully' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Logout failed' });
  }
};
