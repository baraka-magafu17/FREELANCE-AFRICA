// server.js — FreelanceAfrica main entry point
require('dotenv').config();
const express    = require('express');
const http       = require('http');
const { Server } = require('socket.io');
const cors       = require('cors');
const helmet     = require('helmet');
const rateLimit  = require('express-rate-limit');
const path       = require('path');

// ── Routes ────────────────────────────────────────────
const authRoutes     = require('./routes/auth.routes');
const userRoutes     = require('./routes/user.routes');
const gigRoutes      = require('./routes/gig.routes');
const orderRoutes    = require('./routes/order.routes');
const paymentRoutes  = require('./routes/payment.routes');
const reviewRoutes   = require('./routes/review.routes');
const messageRoutes  = require('./routes/message.routes');
const adminRoutes    = require('./routes/admin.routes');

// ── DB (import to trigger connection on startup) ──────
require('./config/db');

const app    = express();
const server = http.createServer(app);

// ── Socket.IO setup ───────────────────────────────────
const io = new Server(server, {
  cors: {
    origin: process.env.FRONTEND_URL || 'http://localhost:3000',
    methods: ['GET', 'POST'],
  },
});

// Attach io to app so controllers can access it
app.set('io', io);

// ── Socket.IO connection handler ──────────────────────
io.on('connection', (socket) => {
  console.log(`🔌  Socket connected: ${socket.id}`);

  // Join a room per order for private messaging
  socket.on('join_order', (orderId) => {
    socket.join(`order_${orderId}`);
    console.log(`   → joined room: order_${orderId}`);
  });

  socket.on('send_message', (data) => {
    // Broadcast to the order room (excluding sender)
    socket.to(`order_${data.order_id}`).emit('new_message', data);
  });

  socket.on('disconnect', () => {
    console.log(`🔌  Socket disconnected: ${socket.id}`);
  });
});

// ── Middleware ────────────────────────────────────────
app.use(helmet());
app.use(cors({ origin: process.env.FRONTEND_URL || 'http://localhost:3000', credentials: true }));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Static uploads folder
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Global rate limit: 100 requests / 15 min per IP
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  message: { success: false, message: 'Too many requests. Please try again later.' },
});
app.use('/api/', limiter);

// ── API Routes ────────────────────────────────────────
app.use('/api/auth',     authRoutes);
app.use('/api/users',    userRoutes);
app.use('/api/gigs',     gigRoutes);
app.use('/api/orders',   orderRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/reviews',  reviewRoutes);
app.use('/api/messages', messageRoutes);
app.use('/api/admin',    adminRoutes);

// ── Health check ──────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({ success: true, message: 'FreelanceAfrica API is running 🚀', env: process.env.NODE_ENV });
});

// ── 404 handler ───────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ success: false, message: 'Route not found' });
});

// ── Global error handler ──────────────────────────────
app.use((err, req, res, next) => {
  console.error('❌ Server Error:', err.stack);
  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'Internal Server Error',
  });
});

// ── Start server ──────────────────────────────────────
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`\n🚀  FreelanceAfrica API running on http://localhost:${PORT}`);
  console.log(`🌍  Environment: ${process.env.NODE_ENV || 'development'}\n`);
});
