-- ============================================================
--  FreelanceAfrica Database Schema
--  Course: Electronic Commerce (ITU_07424)
--  Project: #38/BIT (2A) — FreelanceAfrica
--  Institute of Finance Management (IFM)
--  Normalized to 3NF
-- ============================================================

CREATE DATABASE IF NOT EXISTS freelanceafrica
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE freelanceafrica;

-- ============================================================
-- 1. COUNTRIES (lookup table)
-- ============================================================
CREATE TABLE countries (
  country_id   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  country_code CHAR(2)      NOT NULL UNIQUE,   -- TZ, KE, NG
  country_name VARCHAR(100) NOT NULL,
  currency     CHAR(3)      NOT NULL,           -- TZS, KES, NGN
  created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO countries (country_code, country_name, currency) VALUES
  ('TZ', 'Tanzania',  'TZS'),
  ('KE', 'Kenya',     'KES'),
  ('NG', 'Nigeria',   'NGN');

-- ============================================================
-- 2. CATEGORIES (gig categories)
-- ============================================================
CREATE TABLE categories (
  category_id   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(100) NOT NULL UNIQUE,
  slug          VARCHAR(100) NOT NULL UNIQUE,
  icon          VARCHAR(100),
  description   TEXT,
  is_active     TINYINT(1)   DEFAULT 1,
  created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO categories (name, slug, icon, description) VALUES
  ('Graphic Design',      'graphic-design',      'palette',        'Logos, branding, illustrations'),
  ('Writing & Content',   'writing-content',     'pencil',         'Articles, copywriting, translation'),
  ('Software Development','software-dev',        'code',           'Web, mobile, desktop applications'),
  ('Digital Marketing',   'digital-marketing',   'megaphone',      'SEO, social media, ads'),
  ('Video & Animation',   'video-animation',     'video',          'Editing, motion graphics, explainers'),
  ('Data & Analytics',    'data-analytics',      'chart-bar',      'Data entry, analysis, visualisation'),
  ('Music & Audio',       'music-audio',         'musical-note',   'Voiceover, mixing, jingles'),
  ('Business Consulting', 'business-consulting', 'briefcase',      'Strategy, finance, HR advice');

-- ============================================================
-- 3. USERS (core user table — all roles)
-- ============================================================
CREATE TABLE users (
  user_id           INT UNSIGNED   AUTO_INCREMENT PRIMARY KEY,
  email             VARCHAR(255)   NOT NULL UNIQUE,
  password_hash     VARCHAR(255)   NOT NULL,
  role              ENUM('freelancer','client','admin') NOT NULL DEFAULT 'client',
  first_name        VARCHAR(100)   NOT NULL,
  last_name         VARCHAR(100)   NOT NULL,
  username          VARCHAR(50)    NOT NULL UNIQUE,
  avatar_url        VARCHAR(500),
  bio               TEXT,
  country_id        INT UNSIGNED,
  phone_number      VARCHAR(20),
  is_email_verified TINYINT(1)     DEFAULT 0,
  email_verify_token VARCHAR(255),
  is_active         TINYINT(1)     DEFAULT 1,
  last_login        TIMESTAMP      NULL,
  created_at        TIMESTAMP      DEFAULT CURRENT_TIMESTAMP,
  updated_at        TIMESTAMP      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  FOREIGN KEY (country_id) REFERENCES countries(country_id) ON DELETE SET NULL
);

-- ============================================================
-- 4. FREELANCER_PROFILES (extends users for freelancers)
-- ============================================================
CREATE TABLE freelancer_profiles (
  profile_id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id            INT UNSIGNED NOT NULL UNIQUE,
  tagline            VARCHAR(255),
  years_experience   TINYINT UNSIGNED DEFAULT 0,
  availability       ENUM('available','busy','unavailable') DEFAULT 'available',
  avg_rating         DECIMAL(3,2) DEFAULT 0.00,
  total_reviews      INT UNSIGNED DEFAULT 0,
  total_orders       INT UNSIGNED DEFAULT 0,
  completion_rate    DECIMAL(5,2) DEFAULT 0.00,
  response_time_hrs  TINYINT UNSIGNED DEFAULT 24,
  languages          VARCHAR(255),              -- comma-separated e.g. "English,Swahili"
  portfolio_url      VARCHAR(500),
  linkedin_url       VARCHAR(500),
  created_at         TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
  updated_at         TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- ============================================================
-- 5. FREELANCER_SKILLS
-- ============================================================
CREATE TABLE skills (
  skill_id   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name       VARCHAR(100) NOT NULL UNIQUE,
  slug       VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE freelancer_skills (
  user_id    INT UNSIGNED NOT NULL,
  skill_id   INT UNSIGNED NOT NULL,
  level      ENUM('beginner','intermediate','expert') DEFAULT 'intermediate',
  PRIMARY KEY (user_id, skill_id),
  FOREIGN KEY (user_id)  REFERENCES users(user_id)  ON DELETE CASCADE,
  FOREIGN KEY (skill_id) REFERENCES skills(skill_id) ON DELETE CASCADE
);

-- ============================================================
-- 6. PORTFOLIO_ITEMS
-- ============================================================
CREATE TABLE portfolio_items (
  item_id      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id      INT UNSIGNED NOT NULL,
  title        VARCHAR(255) NOT NULL,
  description  TEXT,
  image_url    VARCHAR(500),
  project_url  VARCHAR(500),
  created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,

  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- ============================================================
-- 7. GIGS (service listings)
-- ============================================================
CREATE TABLE gigs (
  gig_id          INT UNSIGNED   AUTO_INCREMENT PRIMARY KEY,
  freelancer_id   INT UNSIGNED   NOT NULL,
  category_id     INT UNSIGNED   NOT NULL,
  title           VARCHAR(255)   NOT NULL,
  slug            VARCHAR(300)   NOT NULL UNIQUE,
  description     TEXT           NOT NULL,
  thumbnail_url   VARCHAR(500),
  status          ENUM('active','paused','deleted') DEFAULT 'active',
  tags            VARCHAR(500),                 -- comma-separated keywords
  avg_rating      DECIMAL(3,2)   DEFAULT 0.00,
  total_orders    INT UNSIGNED   DEFAULT 0,
  total_reviews   INT UNSIGNED   DEFAULT 0,
  created_at      TIMESTAMP      DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMP      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  FOREIGN KEY (freelancer_id) REFERENCES users(user_id) ON DELETE CASCADE,
  FOREIGN KEY (category_id)   REFERENCES categories(category_id),

  INDEX idx_gig_status     (status),
  INDEX idx_gig_category   (category_id),
  INDEX idx_gig_freelancer (freelancer_id),
  FULLTEXT INDEX idx_gig_search (title, description, tags)
);

-- ============================================================
-- 8. GIG_PACKAGES (Basic / Standard / Premium tiers)
-- ============================================================
CREATE TABLE gig_packages (
  package_id      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  gig_id          INT UNSIGNED NOT NULL,
  tier            ENUM('basic','standard','premium') NOT NULL,
  title           VARCHAR(255) NOT NULL,
  description     TEXT         NOT NULL,
  price           DECIMAL(10,2) NOT NULL,
  currency        CHAR(3)       NOT NULL DEFAULT 'USD',
  delivery_days   TINYINT UNSIGNED NOT NULL,
  revisions       TINYINT UNSIGNED DEFAULT 1,
  includes_source TINYINT(1)   DEFAULT 0,
  includes_commercial_use TINYINT(1) DEFAULT 0,
  created_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,

  UNIQUE KEY unique_gig_tier (gig_id, tier),
  FOREIGN KEY (gig_id) REFERENCES gigs(gig_id) ON DELETE CASCADE
);

-- ============================================================
-- 9. GIG_IMAGES (multiple images per gig)
-- ============================================================
CREATE TABLE gig_images (
  image_id    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  gig_id      INT UNSIGNED NOT NULL,
  image_url   VARCHAR(500) NOT NULL,
  sort_order  TINYINT UNSIGNED DEFAULT 0,
  created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,

  FOREIGN KEY (gig_id) REFERENCES gigs(gig_id) ON DELETE CASCADE
);

-- ============================================================
-- 10. ORDERS
-- ============================================================
CREATE TABLE orders (
  order_id        INT UNSIGNED  AUTO_INCREMENT PRIMARY KEY,
  order_ref       VARCHAR(20)   NOT NULL UNIQUE,  -- e.g. FA-20260001
  client_id       INT UNSIGNED  NOT NULL,
  freelancer_id   INT UNSIGNED  NOT NULL,
  gig_id          INT UNSIGNED  NOT NULL,
  package_id      INT UNSIGNED  NOT NULL,
  status          ENUM(
                    'pending',
                    'active',
                    'delivered',
                    'revision_requested',
                    'completed',
                    'disputed',
                    'cancelled'
                  ) NOT NULL DEFAULT 'pending',
  requirements    TEXT,                           -- client brief/requirements
  delivery_days   TINYINT UNSIGNED NOT NULL,
  due_date        DATE,
  amount          DECIMAL(10,2) NOT NULL,
  currency        CHAR(3)       NOT NULL,
  is_paid         TINYINT(1)    DEFAULT 0,
  completed_at    TIMESTAMP     NULL,
  cancelled_at    TIMESTAMP     NULL,
  cancel_reason   TEXT,
  created_at      TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMP     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  FOREIGN KEY (client_id)     REFERENCES users(user_id),
  FOREIGN KEY (freelancer_id) REFERENCES users(user_id),
  FOREIGN KEY (gig_id)        REFERENCES gigs(gig_id),
  FOREIGN KEY (package_id)    REFERENCES gig_packages(package_id),

  INDEX idx_order_client     (client_id),
  INDEX idx_order_freelancer (freelancer_id),
  INDEX idx_order_status     (status)
);

-- ============================================================
-- 11. ORDER_DELIVERIES (freelancer delivers work)
-- ============================================================
CREATE TABLE order_deliveries (
  delivery_id   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id      INT UNSIGNED NOT NULL,
  message       TEXT,
  file_urls     TEXT,                -- JSON array of file URLs
  delivered_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,

  FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE
);

-- ============================================================
-- 12. PAYMENTS & ESCROW
-- ============================================================
CREATE TABLE payments (
  payment_id       INT UNSIGNED  AUTO_INCREMENT PRIMARY KEY,
  order_id         INT UNSIGNED  NOT NULL,
  payer_id         INT UNSIGNED  NOT NULL,     -- client
  payee_id         INT UNSIGNED  NOT NULL,     -- freelancer
  gateway          ENUM('mpesa','flutterwave') NOT NULL,
  gateway_ref      VARCHAR(255),               -- gateway transaction ID
  amount           DECIMAL(10,2) NOT NULL,
  currency         CHAR(3)       NOT NULL,
  status           ENUM('pending','held','released','refunded','failed') DEFAULT 'pending',
  escrow_held_at   TIMESTAMP     NULL,
  escrow_released_at TIMESTAMP   NULL,
  phone_number     VARCHAR(20),                -- for M-Pesa STK push
  metadata         JSON,                       -- raw gateway response
  created_at       TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  updated_at       TIMESTAMP     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  FOREIGN KEY (order_id) REFERENCES orders(order_id),
  FOREIGN KEY (payer_id) REFERENCES users(user_id),
  FOREIGN KEY (payee_id) REFERENCES users(user_id),

  INDEX idx_payment_order  (order_id),
  INDEX idx_payment_status (status)
);

-- ============================================================
-- 13. WALLET (freelancer earnings balance)
-- ============================================================
CREATE TABLE wallets (
  wallet_id       INT UNSIGNED  AUTO_INCREMENT PRIMARY KEY,
  user_id         INT UNSIGNED  NOT NULL UNIQUE,
  balance         DECIMAL(12,2) DEFAULT 0.00,
  currency        CHAR(3)       NOT NULL DEFAULT 'USD',
  total_earned    DECIMAL(12,2) DEFAULT 0.00,
  total_withdrawn DECIMAL(12,2) DEFAULT 0.00,
  updated_at      TIMESTAMP     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- ============================================================
-- 14. REVIEWS & RATINGS
-- ============================================================
CREATE TABLE reviews (
  review_id       INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id        INT UNSIGNED NOT NULL UNIQUE,
  reviewer_id     INT UNSIGNED NOT NULL,     -- who wrote the review
  reviewee_id     INT UNSIGNED NOT NULL,     -- who is being reviewed
  gig_id          INT UNSIGNED NOT NULL,
  rating          TINYINT UNSIGNED NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment         TEXT,
  is_public       TINYINT(1)   DEFAULT 1,
  created_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,

  FOREIGN KEY (order_id)    REFERENCES orders(order_id),
  FOREIGN KEY (reviewer_id) REFERENCES users(user_id),
  FOREIGN KEY (reviewee_id) REFERENCES users(user_id),
  FOREIGN KEY (gig_id)      REFERENCES gigs(gig_id)
);

-- ============================================================
-- 15. MESSAGES (real-time chat per order)
-- ============================================================
CREATE TABLE messages (
  message_id    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id      INT UNSIGNED NOT NULL,
  sender_id     INT UNSIGNED NOT NULL,
  receiver_id   INT UNSIGNED NOT NULL,
  body          TEXT,
  attachment_url VARCHAR(500),
  is_read       TINYINT(1)   DEFAULT 0,
  sent_at       TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,

  FOREIGN KEY (order_id)   REFERENCES orders(order_id) ON DELETE CASCADE,
  FOREIGN KEY (sender_id)  REFERENCES users(user_id),
  FOREIGN KEY (receiver_id) REFERENCES users(user_id),

  INDEX idx_msg_order  (order_id),
  INDEX idx_msg_sender (sender_id)
);

-- ============================================================
-- 16. NOTIFICATIONS
-- ============================================================
CREATE TABLE notifications (
  notif_id    INT UNSIGNED  AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED  NOT NULL,
  type        VARCHAR(50)   NOT NULL,   -- e.g. 'new_order','payment_received'
  title       VARCHAR(255)  NOT NULL,
  body        TEXT,
  link        VARCHAR(500),
  is_read     TINYINT(1)    DEFAULT 0,
  created_at  TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,

  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
  INDEX idx_notif_user (user_id, is_read)
);

-- ============================================================
-- 17. DISPUTES
-- ============================================================
CREATE TABLE disputes (
  dispute_id    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id      INT UNSIGNED NOT NULL UNIQUE,
  raised_by     INT UNSIGNED NOT NULL,
  reason        TEXT         NOT NULL,
  status        ENUM('open','under_review','resolved_client','resolved_freelancer','closed')
                DEFAULT 'open',
  admin_notes   TEXT,
  resolved_by   INT UNSIGNED NULL,
  resolved_at   TIMESTAMP    NULL,
  created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  FOREIGN KEY (order_id)    REFERENCES orders(order_id),
  FOREIGN KEY (raised_by)   REFERENCES users(user_id),
  FOREIGN KEY (resolved_by) REFERENCES users(user_id)
);

-- ============================================================
-- 18. REFRESH_TOKENS (JWT rotation)
-- ============================================================
CREATE TABLE refresh_tokens (
  token_id    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  token_hash  VARCHAR(255) NOT NULL UNIQUE,
  expires_at  TIMESTAMP    NOT NULL,
  revoked     TINYINT(1)   DEFAULT 0,
  created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,

  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
  INDEX idx_token_user (user_id)
);

-- ============================================================
-- 19. AUDIT_LOG (admin trail)
-- ============================================================
CREATE TABLE audit_log (
  log_id      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED,
  action      VARCHAR(100) NOT NULL,
  entity      VARCHAR(100),
  entity_id   INT UNSIGNED,
  ip_address  VARCHAR(45),
  details     JSON,
  created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,

  INDEX idx_audit_user   (user_id),
  INDEX idx_audit_entity (entity, entity_id)
);
