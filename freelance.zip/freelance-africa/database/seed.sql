-- ============================================================
--  FreelanceAfrica — Seed Data (for demo/testing)
--  Run AFTER schema.sql
--  NOTE: All passwords below are bcrypt hash of "Password123"
-- ============================================================

USE freelanceafrica;

-- Password hash for "Password123" (bcrypt, 12 rounds)
SET @pwd = '$2a$12$3KZ7qLqEXk8/k1xS9.0bI.uV4f0RJj4y3oMfPzNGm6FZbVbnLZQ.q';

-- ── Admin ────────────────────────────────────────────
INSERT INTO users (email, password_hash, role, first_name, last_name, username, country_id, is_email_verified)
VALUES ('admin@freelanceafrica.com', @pwd, 'admin', 'Admin', 'User', 'admin', 1, 1);

-- ── Freelancers (Tanzania, Kenya, Nigeria) ─────────────
INSERT INTO users (email, password_hash, role, first_name, last_name, username, country_id, bio, is_email_verified) VALUES
('baraka.dev@example.com', @pwd, 'freelancer', 'Baraka', 'Magafu', 'baraka_dev', 1, 'Full-stack developer specializing in React & Node.js', 1),
('amina.design@example.com', @pwd, 'freelancer', 'Amina', 'Hassan', 'amina_design', 2, 'Graphic designer with 5 years experience in branding', 1),
('chidi.write@example.com', @pwd, 'freelancer', 'Chidi', 'Okafor', 'chidi_write', 3, 'Content writer & SEO specialist for African businesses', 1);

INSERT INTO freelancer_profiles (user_id, tagline, years_experience, avg_rating, total_reviews, total_orders, completion_rate, response_time_hrs, languages)
SELECT user_id, 'I build modern web applications', 4, 4.8, 24, 31, 96.5, 2, 'English,Swahili' FROM users WHERE username='baraka_dev';

INSERT INTO freelancer_profiles (user_id, tagline, years_experience, avg_rating, total_reviews, total_orders, completion_rate, response_time_hrs, languages)
SELECT user_id, 'Creative logos & brand identities', 5, 4.9, 41, 52, 98.0, 1, 'English,Swahili' FROM users WHERE username='amina_design';

INSERT INTO freelancer_profiles (user_id, tagline, years_experience, avg_rating, total_reviews, total_orders, completion_rate, response_time_hrs, languages)
SELECT user_id, 'SEO-optimized content that converts', 3, 4.7, 18, 22, 94.0, 4, 'English' FROM users WHERE username='chidi_write';

-- Wallets for freelancers
INSERT INTO wallets (user_id, balance, currency, total_earned)
SELECT user_id, 150.00, 'USD', 2400.00 FROM users WHERE username='baraka_dev';
INSERT INTO wallets (user_id, balance, currency, total_earned)
SELECT user_id, 320.00, 'USD', 5100.00 FROM users WHERE username='amina_design';
INSERT INTO wallets (user_id, balance, currency, total_earned)
SELECT user_id, 80.00, 'USD', 1100.00 FROM users WHERE username='chidi_write';

-- ── Clients ────────────────────────────────────────────
INSERT INTO users (email, password_hash, role, first_name, last_name, username, country_id, is_email_verified) VALUES
('john.client@example.com', @pwd, 'client', 'John', 'Mwakatobe', 'john_m', 1, 1),
('sarah.client@example.com', @pwd, 'client', 'Sarah', 'Njoroge', 'sarah_n', 2, 1);

INSERT INTO wallets (user_id, balance, currency) SELECT user_id, 0.00, 'USD' FROM users WHERE username IN ('john_m','sarah_n');

-- ── Sample Gigs ─────────────────────────────────────────
-- Gig 1: Baraka — Web Development
INSERT INTO gigs (freelancer_id, category_id, title, slug, description, status, tags, avg_rating, total_orders, total_reviews)
SELECT user_id, (SELECT category_id FROM categories WHERE slug='software-dev'),
  'I will build a responsive React.js website for your business',
  'i-will-build-a-responsive-react-website-a1b2c3',
  'I will design and develop a fast, mobile-friendly website using React.js and Tailwind CSS. Includes up to 5 pages, contact form, and basic SEO setup. Perfect for small businesses, portfolios, and startups looking for a modern web presence.',
  'active', 'react,website,frontend,webdev', 4.8, 31, 24
FROM users WHERE username='baraka_dev';

INSERT INTO gig_packages (gig_id, tier, title, description, price, currency, delivery_days, revisions)
SELECT gig_id, 'basic', 'Starter Website', '3-page responsive site with contact form', 80.00, 'USD', 5, 1 FROM gigs WHERE slug='i-will-build-a-responsive-react-website-a1b2c3';
INSERT INTO gig_packages (gig_id, tier, title, description, price, currency, delivery_days, revisions)
SELECT gig_id, 'standard', 'Business Website', '5-page site with CMS integration', 180.00, 'USD', 8, 2 FROM gigs WHERE slug='i-will-build-a-responsive-react-website-a1b2c3';
INSERT INTO gig_packages (gig_id, tier, title, description, price, currency, delivery_days, revisions)
SELECT gig_id, 'premium', 'Full Web App', '8+ pages, backend API, authentication', 350.00, 'USD', 14, 3 FROM gigs WHERE slug='i-will-build-a-responsive-react-website-a1b2c3';

-- Gig 2: Amina — Logo Design
INSERT INTO gigs (freelancer_id, category_id, title, slug, description, status, tags, avg_rating, total_orders, total_reviews)
SELECT user_id, (SELECT category_id FROM categories WHERE slug='graphic-design'),
  'I will design a modern minimalist logo for your brand',
  'i-will-design-a-modern-minimalist-logo-d4e5f6',
  'Get a professional, unique logo design tailored to your brand identity. I provide multiple concepts, unlimited color variations, and all source files (AI, PNG, SVG). Ideal for startups, e-commerce stores, and personal brands across East Africa.',
  'active', 'logo,branding,design,graphic', 4.9, 52, 41
FROM users WHERE username='amina_design';

INSERT INTO gig_packages (gig_id, tier, title, description, price, currency, delivery_days, revisions)
SELECT gig_id, 'basic', 'Simple Logo', '1 concept, 2 revisions, PNG + JPG files', 25.00, 'USD', 2, 2 FROM gigs WHERE slug='i-will-design-a-modern-minimalist-logo-d4e5f6';
INSERT INTO gig_packages (gig_id, tier, title, description, price, currency, delivery_days, revisions)
SELECT gig_id, 'standard', 'Brand Logo Pack', '3 concepts, vector files, brand guide', 60.00, 'USD', 4, 3 FROM gigs WHERE slug='i-will-design-a-modern-minimalist-logo-d4e5f6';
INSERT INTO gig_packages (gig_id, tier, title, description, price, currency, delivery_days, revisions)
SELECT gig_id, 'premium', 'Full Brand Identity', '5 concepts + business card + social kit', 120.00, 'USD', 7, 5 FROM gigs WHERE slug='i-will-design-a-modern-minimalist-logo-d4e5f6';

-- Gig 3: Chidi — Content Writing
INSERT INTO gigs (freelancer_id, category_id, title, slug, description, status, tags, avg_rating, total_orders, total_reviews)
SELECT user_id, (SELECT category_id FROM categories WHERE slug='writing-content'),
  'I will write SEO-optimized blog posts and articles',
  'i-will-write-seo-optimized-blog-posts-g7h8i9',
  'Professional, well-researched, and SEO-friendly articles for your blog or website. I cover topics in tech, business, finance, lifestyle, and African markets. Each article includes keyword research and meta description.',
  'active', 'writing,seo,content,blog', 4.7, 22, 18
FROM users WHERE username='chidi_write';

INSERT INTO gig_packages (gig_id, tier, title, description, price, currency, delivery_days, revisions)
SELECT gig_id, 'basic', '500-word Article', '1 SEO article, basic research', 15.00, 'USD', 2, 1 FROM gigs WHERE slug='i-will-write-seo-optimized-blog-posts-g7h8i9';
INSERT INTO gig_packages (gig_id, tier, title, description, price, currency, delivery_days, revisions)
SELECT gig_id, 'standard', '1000-word Article', 'In-depth article with keyword research', 30.00, 'USD', 3, 2 FROM gigs WHERE slug='i-will-write-seo-optimized-blog-posts-g7h8i9';
INSERT INTO gig_packages (gig_id, tier, title, description, price, currency, delivery_days, revisions)
SELECT gig_id, 'premium', '5-Article Package', '5 x 1000-word articles + meta descriptions', 130.00, 'USD', 7, 3 FROM gigs WHERE slug='i-will-write-seo-optimized-blog-posts-g7h8i9';
